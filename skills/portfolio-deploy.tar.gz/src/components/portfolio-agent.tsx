"use client"

import { useState, useEffect } from "react"

const VPS_API_URL = "http://65.109.11.40:3001"
const USER_NAME = "Kai"

const AVATARS = {
  user: "🦸",
  ai: "🦞",
  bull: "🐂",
  bear: "🐻",
  rocket: "🚀",
  money: "💰"
}

const FUN_RESPONSES = {
  greeting: [
    "Yo! What's up? Ready to make some money? 💰",
    "Hey there! Your stocks are doing... things! 📈",
    "Welcome back! Let's check if we're rich yet! 🤑",
    "Hola! Time to see if our gamble paid off! 🎲"
  ],
  positive: [
    "TO THE MOON! 🚀🚀🚀",
    "We're rich! Well, richer than yesterday! 💎",
    "Cha-ching! Money machine go brrr! 🖨️💵",
    "Green day = happy day! 🟢😄"
  ],
  negative: [
    "It's just a dip... right? RIGHT?! 😅",
    "Buy the dip? Or cry? Why not both! 😭",
    "Stonks only go up! ...eventually... 📉",
    "HODL! Diamond hands! 💎🙌"
  ]
}

export function PortfolioAgent() {
  const [holdings, setHoldings] = useState([])
  const [totalValue, setTotalValue] = useState(0)
  const [totalPnl, setTotalPnl] = useState(0)
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [dataLoaded, setDataLoaded] = useState(false)
  const [aiMood, setAiMood] = useState('neutral')

  const fetchPortfolio = async () => {
    try {
      const res = await fetch(`${VPS_API_URL}/api/portfolio`)
      const data = await res.json()
      setHoldings(data.holdings)
      setTotalValue(data.totalValue)
      setTotalPnl(data.pnl)
      setAiMood(data.pnl >= 0 ? 'happy' : 'sad')
      
      if (!dataLoaded) {
        const greeting = FUN_RESPONSES.greeting[Math.floor(Math.random() * FUN_RESPONSES.greeting.length)]
        const portfolioMsg = `${greeting}\n\n📊 HERE'S THE DAMAGE:\n\n${data.holdings.map(h => 
          `${h.change >= 0 ? '🚀' : '📉'} ${h.symbol}: $${h.price.toFixed(2)} (${h.change >= 0 ? '+' : ''}${h.change.toFixed(1)}%)`
        ).join('\n')}\n\n💰 Total: $${data.totalValue.toLocaleString()}\n📈 P&L: ${data.pnl >= 0 ? '🟢 +' : '🔴 '}$${data.pnl.toLocaleString()}\n\nAsk me stuff or type 'help'!`
        
        setMessages([{ role: "ai", content: portfolioMsg, avatar: AVATARS.ai }])
        setDataLoaded(true)
      }
    } catch (e) {
      console.error('Failed to fetch:', e)
    }
  }

  useEffect(() => {
    fetchPortfolio()
    const interval = setInterval(fetchPortfolio, 30000)
    return () => clearInterval(interval)
  }, [])

  const getStockInfo = (symbol) => {
    return holdings.find(h => h.symbol === symbol.toUpperCase())
  }

  const generateFunResponse = (stock, type) => {
    const responses = {
      NVDA: {
        good: ["NVIDIA is printing money! AI takeover is real! 🤖💰", "Jensen Huang is my hero! 🦸‍♂️", "Blackwell chips = black card lifestyle! 💳"],
        bad: ["NVDA taking a nap... it'll wake up! 😴", "Even AI needs a break sometimes! 🧠💤"]
      },
      ONDS: {
        good: ["ONDS to the MOON! 🚀 Defense contracts = $$$", "Israel contract = BIG MONEY! 💵", "Drones gonna make us rich! 🛸"],
        bad: ["ONDS is... finding itself... spiritually... 🧘", "Patience! Defense takes time! ⏰"]
      },
      SLS: {
        good: ["Biotech baby! Science is happening! 🧪", "Maybe the cure for... our portfolio? 💊"],
        bad: ["SLS is doing biotech things... slowly... 🐌", "Waiting for that FDA approval! 📋"]
      },
      VOO: {
        good: ["VOO just vibin', steady as always! 😎", "S&P 500 = Sleep & Profit 500 😴💰"],
        bad: ["VOO is chill, like always! 🧘‍♂️", "Index funds don't care about your feelings! 📊"]
      }
    }
    
    const list = responses[stock.symbol]?.[type] || ["Stonks! 📈"]
    return list[Math.floor(Math.random() * list.length)]
  }

  const handleSend = async () => {
    if (!input.trim()) return
    const userMsg = input
    setMessages([...messages, { role: "user", content: userMsg, avatar: AVATARS.user }])
    setInput("")
    setLoading(true)

    setTimeout(() => {
      let response = ""
      let responseAvatar = AVATARS.ai
      const lower = userMsg.toLowerCase()
      
      for (const symbol of ['NVDA', 'ONDS', 'SLS', 'VOO']) {
        if (lower.includes(symbol.toLowerCase())) {
          const stock = getStockInfo(symbol)
          if (stock) {
            const isGood = stock.change >= 0
            const funComment = generateFunResponse(stock, isGood ? 'good' : 'bad')
            responseAvatar = isGood ? AVATARS.rocket : AVATARS.bear
            
            response = `${funComment}\n\n` +
              `📊 ${symbol} STATS:\n` +
              `💰 Price: $${stock.price.toFixed(2)}\n` +
              `📈 Change: ${stock.change >= 0 ? '🟢 +' : '🔴 '}${stock.change.toFixed(1)}%\n` +
              `💵 Your Position: ${stock.shares} shares\n` +
              `💎 Value: $${stock.value.toLocaleString()}\n` +
              `📉 P&L: ${stock.pnl >= 0 ? '💚 +' : '💔 '}$${stock.pnl.toLocaleString()}\n\n` +
              `${isGood ? FUN_RESPONSES.positive[Math.floor(Math.random() * FUN_RESPONSES.positive.length)] : FUN_RESPONSES.negative[Math.floor(Math.random() * FUN_RESPONSES.negative.length)]}`
          }
          break
        }
      }
      
      if (!response && (lower.includes("portfolio") || lower.includes("total"))) {
        const isGood = totalPnl >= 0
        responseAvatar = isGood ? AVATARS.money : AVATARS.bear
        response = `${isGood ? "We're winning! 🎉" : "We're learning... 📚"}\n\n` +
          `💰 Total Stash: $${totalValue.toLocaleString()}\n` +
          `📈 P&L: ${totalPnl >= 0 ? '🟢 +' : '🔴 '}$${totalPnl.toLocaleString()}\n\n` +
          `📊 Breakdown:\n${holdings.map(h => 
            `${h.change >= 0 ? '💚' : '💔'} ${h.symbol}: ${((h.value/totalValue)*100).toFixed(0)}%`
          ).join('\n')}\n\n` +
          `${isGood ? FUN_RESPONSES.positive[0] : FUN_RESPONSES.negative[0]}`
      } else if (!response && lower.includes("help")) {
        response = `🦞 What I can do:\n\n` +
          `📈 "NVDA", "ONDS", "SLS", "VOO" - Stock details\n` +
          `💰 "portfolio" or "total" - Full summary\n` +
          `🚀 "moon" - Motivation\n` +
          `😭 "cry" - Emotional support\n\n` +
          `Just type and I'll help! Or entertain you... 😄`
      } else if (!response && (lower.includes("moon") || lower.includes("lambo"))) {
        response = "🚀🚀🚀 TO THE MOON! 🌕\n\nWhen Lambo? Soon! Just keep HODLing! 💎🙌\n\nRemember: We're not gambling, we're 'investing'! 😉"
        responseAvatar = AVATARS.rocket
      } else if (!response && (lower.includes("cry") || lower.includes("sad"))) {
        response = "😭 There there... \n\nIt's just money! You can't take it to the grave! \n\n...but you can lose it in the market! 😅\n\nHODL! Tomorrow is another day! 🌅"
        responseAvatar = AVATARS.bear
      } else if (!response) {
        response = `🤔 Hmm, not sure what you mean!\n\nTry:\n• "NVDA" for stock info\n• "portfolio" for summary\n• "moon" for hype\n• "help" for all options\n\nOr just tell me about your feelings! I'm a good listener! 🦞👂`
      }
      
      setMessages(prev => [...prev, { role: "ai", content: response, avatar: responseAvatar }])
      setLoading(false)
    }, 600)
  }

  return (
    <div className="h-[450px] flex flex-col bg-white rounded-3xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] font-comic overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-400 to-pink-400 p-4 border-b-4 border-black">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-4xl animate-wiggle">{AVATARS.ai}</span>
            <div>
              <p className="font-black text-xl text-black">Portfolio Pal</p>
              <p className="text-sm font-bold text-black/70">
                {aiMood === 'happy' ? "Feeling bullish! 🐂" : aiMood === 'sad' ? "Bear market blues... 🐻" : "Just vibin' 😎"}
              </p>
            </div>
          </div>
          <div className="bg-white px-3 py-1 rounded-full border-2 border-black font-bold text-sm shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            {aiMood === 'happy' ? '🟢 Live' : aiMood === 'sad' ? '🔴 Oof' : '🟡 Live'}
          </div>
        </div>
      </div>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-blue-50">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <div className="text-5xl animate-bounce">{AVATARS.ai}</div>
            <p className="ml-3 text-lg font-bold">Waking up...</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`flex gap-2 max-w-[85%] ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <span className="text-2xl">{m.avatar}</span>
              <div className={`p-3 rounded-2xl border-3 border-black whitespace-pre-line shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] ${
                m.role === "user" 
                  ? "bg-green-400 text-black" 
                  : "bg-white text-black"
              }`}>
                <p className="text-sm font-bold">{m.content}</p>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="flex gap-2">
              <span className="text-2xl">{AVATARS.ai}</span>
              <div className="bg-white p-3 rounded-2xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <p className="text-sm font-bold">Thinking...</p>
                <div className="flex gap-1 mt-1">
                  <span className="animate-bounce">💭</span>
                  <span className="animate-bounce" style={{animationDelay: '0.1s'}}>💭</span>
                  <span className="animate-bounce" style={{animationDelay: '0.2s'}}>💭</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Input */}
      <div className="p-4 bg-white border-t-4 border-black">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask about stocks, type 'help', or just chat!"
            className="flex-1 bg-yellow-100 text-black px-4 py-3 rounded-full border-4 border-black font-bold shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] focus:outline-none focus:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] focus:translate-y-1 transition-all"
          />
          <button 
            onClick={handleSend} 
            disabled={loading}
            className="bg-pink-400 text-black px-6 py-3 rounded-full border-4 border-black font-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:bg-pink-300 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 transition-all disabled:opacity-50"
          >
            {loading ? "..." : "SEND! 🚀"}
          </button>
        </div>
        <p className="text-center text-xs font-bold text-slate-500 mt-2">
          💡 Try: "NVDA", "portfolio", "moon", "cry", or "help"
        </p>
      </div>
    </div>
  )
}
