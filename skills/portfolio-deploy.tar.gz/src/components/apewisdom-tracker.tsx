"use client"

import { useState, useEffect } from "react"
import { 
  MessageSquare, TrendingUp, TrendingDown, ArrowUpRight, 
  Users, Activity, Zap, Award, Flame, Clock
} from "lucide-react"

// ApeWisdom-style data - Reddit/WallStreetBets tracking
const APEWISDOM_DATA = {
  lastUpdated: new Date().toISOString(),
  topMentions: [
    { rank: 1, ticker: "NVDA", mentions: 15432, change24h: 234, sentiment: 78, subreddits: ["wallstreetbets", "stocks", "nvidia"] },
    { rank: 2, ticker: "TSLA", mentions: 12891, change24h: -156, sentiment: 62, subreddits: ["wallstreetbets", "teslainvestorsclub"] },
    { rank: 3, ticker: "RKLB", mentions: 8934, change24h: 445, sentiment: 84, subreddits: ["wallstreetbets", "spacstocks"] },
    { rank: 5, ticker: "ONDS", mentions: 5432, change24h: 289, sentiment: 76, subreddits: ["wallstreetbets", "smallstreetbets", "defensestocks"] },
    { rank: 12, ticker: "SLS", mentions: 1234, change24h: -45, sentiment: 48, subreddits: ["biotech", "pennystocks"] },
    { rank: 45, ticker: "VOO", mentions: 892, change24h: 23, sentiment: 71, subreddits: ["bogleheads", "personalfinance"] },
  ],
  trending: [
    { ticker: "RKLB", mentions: 8934, rocket: true, reason: "Space infrastructure boom" },
    { ticker: "ONDS", mentions: 5432, rocket: true, reason: "$45M defense contracts" },
    { ticker: "ASTS", mentions: 4321, rocket: true, reason: "Satellite-to-cell hype" },
    { ticker: "NVDA", mentions: 15432, rocket: false, reason: "Consistent top mention" },
  ],
  sentimentLeaders: {
    bullish: ["RKLB", "ONDS", "NVDA", "PLTR"],
    bearish: ["SLS", "TLRY", "GME"],
    controversial: ["TSLA", "AMD", "INTC"]
  },
  yourPortfolio: {
    NVDA: {
      mentions24h: 15432,
      rank: 1,
      change: 234,
      sentiment: 78,
      bullishPosts: 72,
      bearishPosts: 18,
      awards: 2341,
      topSubreddit: "wallstreetbets",
      trendingPhrase: "Blackwell chips",
      yoloPosts: 45,
      ddPosts: 23
    },
    ONDS: {
      mentions24h: 5432,
      rank: 5,
      change: 289,
      sentiment: 76,
      bullishPosts: 68,
      bearishPosts: 22,
      awards: 892,
      topSubreddit: "smallstreetbets",
      trendingPhrase: "defense contracts",
      yoloPosts: 12,
      ddPosts: 8
    },
    SLS: {
      mentions24h: 1234,
      rank: 12,
      change: -45,
      sentiment: 48,
      bullishPosts: 32,
      bearishPosts: 45,
      awards: 123,
      topSubreddit: "biotech",
      trendingPhrase: "FDA approval",
      yoloPosts: 3,
      ddPosts: 15
    },
    VOO: {
      mentions24h: 892,
      rank: 45,
      change: 23,
      sentiment: 71,
      bullishPosts: 65,
      bearishPosts: 15,
      awards: 67,
      topSubreddit: "bogleheads",
      trendingPhrase: "dollar cost average",
      yoloPosts: 0,
      ddPosts: 2
    }
  },
  wsbMood: "greedy", // fearful, neutral, greedy, euphoric
  wsbIndex: 78,
  popularThreads: [
    { title: "NVDA to $300 by March? Here's why...", upvotes: 12453, awards: 45, comments: 892 },
    { title: "ONDS just secured $45M in contracts - undervalued?", upvotes: 8934, awards: 23, comments: 567 },
    { title: "Why I'm loading up on defense stocks", upvotes: 6543, awards: 12, comments: 432 },
  ]
}

export function ApeWisdomTracker() {
  const [activeView, setActiveView] = useState('portfolio')
  const [selectedStock, setSelectedStock] = useState(null)
  const [timeRange, setTimeRange] = useState('24h')

  const getRankChange = (change) => {
    if (change > 100) return { icon: '🚀', color: 'text-green-400', label: 'Trending' }
    if (change > 0) return { icon: '↑', color: 'text-green-400', label: 'Rising' }
    if (change < -50) return { icon: '↓', color: 'text-red-400', label: 'Falling' }
    return { icon: '→', color: 'text-zinc-400', label: 'Stable' }
  }

  const getSentimentColor = (score) => {
    if (score >= 70) return 'text-green-400'
    if (score >= 50) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getSentimentBg = (score) => {
    if (score >= 70) return 'bg-green-500'
    if (score >= 50) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">🦍</span>
            ApeWisdom Tracker
          </h3>
          <p className="text-zinc-500 text-sm mt-1">
            Reddit & WallStreetBets sentiment monitoring
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 rounded-lg border border-zinc-800">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-zinc-400">WSB Mood:</span>
            <span className={`text-xs font-bold ${
              APEWISDOM_DATA.wsbMood === 'euphoric' ? 'text-purple-400' :
              APEWISDOM_DATA.wsbMood === 'greedy' ? 'text-green-400' :
              APEWISDOM_DATA.wsbMood === 'fearful' ? 'text-red-400' :
              'text-yellow-400'
            }`}>
              {APEWISDOM_DATA.wsbMood.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* WSB Fear & Greed Style Index */}
      <div className="card-sleek p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium text-zinc-400">WSB Sentiment Index</h4>
          <span className="text-xs text-zinc-500">Updated: Just now</span>
        </div>
        <div className="relative h-8 bg-zinc-900 rounded-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-red-600 via-yellow-500 to-green-500 opacity-30"></div>
          <div 
            className="absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
            style={{ left: `${APEWISDOM_DATA.wsbIndex}%` }}
          />
          <div className="absolute inset-0 flex items-center justify-between px-4 text-xs font-medium">
            <span className="text-red-400">Fear</span>
            <span className="text-yellow-400">Neutral</span>
            <span className="text-green-400">Greed</span>
          </div>
        </div>
        <div className="flex justify-center mt-2">
          <span className="text-2xl font-bold">{APEWISDOM_DATA.wsbIndex}/100</span>
        </div>
      </div>

      {/* View Toggle */}
      <div className="flex gap-1 p-1 bg-zinc-950 rounded-lg border border-zinc-800 w-fit">
        {[
          { id: 'portfolio', label: 'Your Stocks' },
          { id: 'trending', label: '🔥 Trending' },
          { id: 'top', label: '📊 Top Mentions' },
          { id: 'threads', label: '💬 Hot Threads' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveView(tab.id)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeView === tab.id ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Portfolio View */}
      {activeView === 'portfolio' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm text-zinc-500">
            <span>Your portfolio stocks on Reddit</span>
            <div className="flex gap-2">
              {['24h', '7d', '30d'].map(range => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-2 py-1 rounded text-xs ${
                    timeRange === range ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
          </div>

          {Object.entries(APEWISDOM_DATA.yourPortfolio)
            .sort((a, b) => b[1].mentions24h - a[1].mentions24h)
            .map(([ticker, data]) => {
              const rankInfo = getRankChange(data.change)
              return (
                <div 
                  key={ticker}
                  className="card-sleek p-5 cursor-pointer hover:border-zinc-600 transition-all"
                  onClick={() => setSelectedStock({ ticker, ...data })}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-center w-12">
                        <span className="text-xs text-zinc-500">Rank</span>
                        <p className="text-2xl font-bold">#{data.rank}</p>
                        <span className={`text-xs ${rankInfo.color}`}>{rankInfo.icon}</span>
                      </div>
                      
                      <div>
                        <h4 className="font-mono font-bold text-xl">{ticker}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-sm ${data.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {data.change > 0 ? '+' : ''}{data.change} mentions
                          </span>
                          <span className="text-xs text-zinc-500">({timeRange})</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-3xl font-bold">{data.mentions24h.toLocaleString()}</p>
                      <p className="text-xs text-zinc-500">mentions</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-zinc-800 grid grid-cols-4 gap-4">
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Sentiment</p>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${getSentimentBg(data.sentiment)}`}
                            style={{ width: `${data.sentiment}%` }}
                          />
                        </div>
                        <span className={`text-sm font-bold ${getSentimentColor(data.sentiment)}`}>
                          {data.sentiment}%
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Awards</p>
                      <p className="font-medium flex items-center gap-1">
                        <Award size={14} className="text-yellow-500" />
                        {data.awards.toLocaleString()}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">YOLO Posts</p>
                      <p className="font-medium text-orange-400">{data.yoloPosts}</p>
                    </div>
                    
                    <div>
                      <p className="text-xs text-zinc-500 mb-1">Top Sub</p>
                      <p className="font-medium text-xs">r/{data.topSubreddit}</p>
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <span className="px-2 py-1 bg-zinc-950 rounded text-xs text-zinc-400">
                      Trending: "{data.trendingPhrase}"
                    </span>
                    <span className="px-2 py-1 bg-zinc-950 rounded text-xs text-zinc-400">
                      {data.bullishPosts}% bullish
                    </span>
                    <span className="px-2 py-1 bg-zinc-950 rounded text-xs text-zinc-400">
                      {data.ddPosts} DD posts
                    </span>
                  </div>
                </div>
              )
            })}
        </div>
      )}

      {/* Trending View */}
      {activeView === 'trending' && (
        <div className="space-y-4">
          <p className="text-sm text-zinc-500">Stocks with unusual mention activity</p>
          {APEWISDOM_DATA.trending.map((stock, idx) => (
            <div key={stock.ticker} className="card-sleek p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center">
                  {stock.rocket ? (
                    <span className="text-2xl">🚀</span>
                  ) : (
                    <span className="text-xl">📈</span>
                  )}
                </div>
                <div>
                  <h4 className="font-mono font-bold text-lg">{stock.ticker}</h4>
                  <p className="text-sm text-zinc-500">{stock.reason}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold">{stock.mentions.toLocaleString()}</p>
                <p className="text-xs text-zinc-500">mentions today</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Top Mentions View */}
      {activeView === 'top' && (
        <div className="card-sleek overflow-hidden">
          <table className="w-full">
            <thead className="bg-zinc-950 border-b border-zinc-800">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-zinc-400">Rank</th>
                <th className="text-left p-4 text-sm font-medium text-zinc-400">Ticker</th>
                <th className="text-right p-4 text-sm font-medium text-zinc-400">Mentions</th>
                <th className="text-right p-4 text-sm font-medium text-zinc-400">24h Change</th>
                <th className="text-right p-4 text-sm font-medium text-zinc-400">Sentiment</th>
                <th className="text-left p-4 text-sm font-medium text-zinc-400">Top Subreddit</th>
              </tr>
            </thead>
            <tbody>
              {APEWISDOM_DATA.topMentions.map((stock) => {
                const isInPortfolio = Object.keys(APEWISDOM_DATA.yourPortfolio).includes(stock.ticker)
                return (
                  <tr 
                    key={stock.ticker} 
                    className={`border-b border-zinc-800/50 hover:bg-zinc-900/50 transition-colors ${
                      isInPortfolio ? 'bg-zinc-900/30' : ''
                    }`}
                  >
                    <td className="p-4 font-bold">#{stock.rank}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold">{stock.ticker}</span>
                        {isInPortfolio && (
                          <span className="px-2 py-0.5 bg-blue-950 text-blue-400 rounded text-xs">Portfolio</span>
                        )}
                      </div>
                    </td>
                    <td className="p-4 text-right font-mono">{stock.mentions.toLocaleString()}</td>
                    <td className={`p-4 text-right ${stock.change24h > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {stock.change24h > 0 ? '+' : ''}{stock.change24h}
                    </td>
                    <td className="p-4 text-right">
                      <span className={getSentimentColor(stock.sentiment)}>{stock.sentiment}%</span>
                    </td>
                    <td className="p-4 text-sm text-zinc-400">r/{stock.subreddits[0]}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Hot Threads View */}
      {activeView === 'threads' && (
        <div className="space-y-4">
          <p className="text-sm text-zinc-500">Most discussed posts about your stocks</p>
          {APEWISDOM_DATA.popularThreads.map((thread, idx) => (
            <div key={idx} className="card-sleek p-5 hover:border-zinc-600 transition-all cursor-pointer">
              <h4 className="font-bold text-lg mb-2 hover:text-blue-400 transition-colors">
                {thread.title}
              </h4>
              <div className="flex items-center gap-4 text-sm text-zinc-500">
                <span className="flex items-center gap-1">
                  <ArrowUpRight size={14} />
                  {thread.upvotes.toLocaleString()} upvotes
                </span>
                <span className="flex items-center gap-1">
                  <Award size={14} className="text-yellow-500" />
                  {thread.awards} awards
                </span>
                <span className="flex items-center gap-1">
                  <MessageSquare size={14} />
                  {thread.comments} comments
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Stock Detail Modal */}
      {selectedStock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedStock(null)}>
          <div className="bg-zinc-900 rounded-2xl border border-zinc-700 max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="font-mono font-bold text-2xl">{selectedStock.ticker}</span>
                <span className="text-zinc-500">Rank #{selectedStock.rank}</span>
              </div>
              <button onClick={() => setSelectedStock(null)} className="p-2 hover:bg-zinc-800 rounded-lg">
                <span className="text-2xl">×</span>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-zinc-950 rounded-xl text-center">
                  <p className="text-sm text-zinc-500 mb-1">24h Mentions</p>
                  <p className="text-2xl font-bold">{selectedStock.mentions24h.toLocaleString()}</p>
                </div>
                <div className="p-4 bg-zinc-950 rounded-xl text-center">
                  <p className="text-sm text-zinc-500 mb-1">Sentiment</p>
                  <p className={`text-2xl font-bold ${getSentimentColor(selectedStock.sentiment)}`}>
                    {selectedStock.sentiment}%
                  </p>
                </div>
                <div className="p-4 bg-zinc-950 rounded-xl text-center">
                  <p className="text-sm text-zinc-500 mb-1">Awards</p>
                  <p className="text-2xl font-bold text-yellow-500">{selectedStock.awards}</p>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-zinc-400 mb-3">Post Breakdown</h4>
                <div className="h-4 bg-zinc-800 rounded-full overflow-hidden flex">
                  <div className="h-full bg-green-500" style={{ width: `${selectedStock.bullishPosts}%` }} />
                  <div className="h-full bg-red-500" style={{ width: `${selectedStock.bearishPosts}%` }} />
                  <div className="h-full bg-zinc-500" style={{ width: `${100 - selectedStock.bullishPosts - selectedStock.bearishPosts}%` }} />
                </div>
                <div className="flex justify-between mt-2 text-sm">
                  <span className="text-green-400">{selectedStock.bullishPosts}% Bullish</span>
                  <span className="text-red-400">{selectedStock.bearishPosts}% Bearish</span>
                  <span className="text-zinc-500">{100 - selectedStock.bullishPosts - selectedStock.bearishPosts}% Neutral</span>
                </div>
              </div>

              <div className="p-4 bg-zinc-950 rounded-xl">
                <h4 className="font-medium text-zinc-400 mb-2">Trending Phrase</h4>
                <p className="text-lg font-medium">"{selectedStock.trendingPhrase}"</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-zinc-950 rounded-xl">
                  <p className="text-sm text-zinc-500 mb-1">YOLO Posts</p>
                  <p className="text-2xl font-bold text-orange-400">{selectedStock.yoloPosts}</p>
                </div>
                <div className="p-4 bg-zinc-950 rounded-xl">
                  <p className="text-sm text-zinc-500 mb-1">Due Diligence</p>
                  <p className="text-2xl font-bold text-blue-400">{selectedStock.ddPosts}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
