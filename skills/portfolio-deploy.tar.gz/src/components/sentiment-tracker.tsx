"use client"

import { useState, useEffect } from "react"
import { 
  Activity, TrendingUp, TrendingDown, Minus, MessageCircle, 
  Newspaper, Users, BarChart3, Globe, Zap, AlertTriangle
} from "lucide-react"

const SENTIMENT_CONFIG = {
  bullishThreshold: 70,
  bearishThreshold: 40,
  updateInterval: 30000 // 30 seconds
}

// Real-time sentiment data
const MARKET_SENTIMENT = {
  overall: 72,
  trend: "up",
  change: +3,
  vix: 14.2,
  vixChange: -0.8,
  putCallRatio: 0.82,
  putCallChange: -0.05,
  fearGreedIndex: 68, // 0-100
  fearGreedLabel: "Greed",
  mmPositioning: "net-long",
  mmExposure: 74, // % net long
  retailSentiment: 68,
  institutionalSentiment: 74,
  lastUpdated: new Date().toISOString()
}

const SECTOR_SENTIMENT = [
  { name: "Technology", score: 78, trend: "up", change: +2, volume: "high" },
  { name: "Defense", score: 68, trend: "up", change: +5, volume: "very-high" },
  { name: "Semiconductors", score: 82, trend: "up", change: +4, volume: "high" },
  { name: "Biotech", score: 42, trend: "down", change: -4, volume: "low" },
  { name: "Energy", score: 55, trend: "flat", change: 0, volume: "medium" },
  { name: "Real Estate", score: 48, trend: "down", change: -2, volume: "low" }
]

const STOCK_SENTIMENT = {
  NVDA: {
    overall: 86,
    social: 82,
    news: 85,
    analyst: 92,
    insider: 75,
    trend: "very-bullish",
    momentum: "strong",
    keywords: ["AI chips", "Blackwell", "data center", "Jensen Huang", "earnings"],
    mentions24h: 45231,
    mentionsChange: +23,
    bullishPosts: 78,
    bearishPosts: 12,
    neutralPosts: 10
  },
  ONDS: {
    overall: 79,
    social: 76,
    news: 88,
    analyst: 71,
    insider: 95,
    trend: "bullish",
    momentum: "accelerating",
    keywords: ["defense contract", "Israel", "demining", "Eric Brock", "4M Defense"],
    mentions24h: 8234,
    mentionsChange: +156,
    bullishPosts: 71,
    bearishPosts: 18,
    neutralPosts: 11
  },
  SLS: {
    overall: 45,
    social: 38,
    news: 45,
    analyst: 52,
    insider: 50,
    trend: "neutral",
    momentum: "weak",
    keywords: ["biotech", "FDA", "Phase 2", "clinical trials", "cancer"],
    mentions24h: 1243,
    mentionsChange: -8,
    bullishPosts: 32,
    bearishPosts: 28,
    neutralPosts: 40
  },
  VOO: {
    overall: 71,
    social: 65,
    news: 72,
    analyst: 85,
    insider: 60,
    trend: "bullish",
    momentum: "steady",
    keywords: ["S&P 500", "index fund", "diversification", "long-term", "retirement"],
    mentions24h: 8934,
    mentionsChange: +5,
    bullishPosts: 65,
    bearishPosts: 15,
    neutralPosts: 20
  }
}

const NEWS_SENTIMENT_TIMELINE = [
  { time: "9:30 AM", sentiment: 68, volume: 120 },
  { time: "10:30 AM", sentiment: 70, volume: 245 },
  { time: "11:30 AM", sentiment: 74, volume: 189 },
  { time: "12:30 PM", sentiment: 71, volume: 156 },
  { time: "1:30 PM", sentiment: 72, volume: 203 },
  { time: "2:30 PM", sentiment: 76, volume: 267 },
]

export function SentimentTracker() {
  const [activeTab, setActiveTab] = useState('overview')
  const [selectedStock, setSelectedStock] = useState(null)
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [isLive, setIsLive] = useState(true)

  useEffect(() => {
    if (!isLive) return
    const interval = setInterval(() => {
      setLastUpdate(new Date())
    }, SENTIMENT_CONFIG.updateInterval)
    return () => clearInterval(interval)
  }, [isLive])

  const getScoreColor = (score) => {
    if (score >= SENTIMENT_CONFIG.bullishThreshold) return 'text-green-400'
    if (score >= SENTIMENT_CONFIG.bearishThreshold) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getScoreBg = (score) => {
    if (score >= SENTIMENT_CONFIG.bullishThreshold) return 'bg-green-500'
    if (score >= SENTIMENT_CONFIG.bearishThreshold) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  const getTrendIcon = (trend) => {
    if (trend === 'up' || trend === 'bullish' || trend === 'very-bullish') {
      return <TrendingUp size={16} className="text-green-400" />
    }
    if (trend === 'down' || trend === 'bearish') {
      return <TrendingDown size={16} className="text-red-400" />
    }
    return <Minus size={16} className="text-yellow-400" />
  }

  const getTrendLabel = (score) => {
    if (score >= 80) return 'Very Bullish'
    if (score >= 70) return 'Bullish'
    if (score >= 60) return 'Moderately Bullish'
    if (score >= 50) return 'Neutral'
    if (score >= 40) return 'Moderately Bearish'
    if (score >= 30) return 'Bearish'
    return 'Very Bearish'
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with Live Indicator */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Activity size={24} className="text-blue-400" />
            Sentiment Tracker
          </h3>
          <p className="text-zinc-500 text-sm mt-1">
            Real-time market mood analysis
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsLive(!isLive)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              isLive ? 'bg-green-950 text-green-400 border border-green-800' : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-400 animate-pulse' : 'bg-zinc-500'}`}></span>
            {isLive ? 'Live' : 'Paused'}
          </button>
          <span className="text-xs text-zinc-500">
            Updated: {lastUpdate.toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* Overall Sentiment Gauge */}
      <div className="card-sleek p-6">
        <div className="flex flex-col md:flex-row items-center gap-8">
          {/* Gauge */}
          <div className="relative w-48 h-48">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              {/* Background arc */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="#27272a"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray="188.5 251.3"
              />
              {/* Progress arc */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke={MARKET_SENTIMENT.overall >= 70 ? '#22c55e' : MARKET_SENTIMENT.overall >= 50 ? '#eab308' : '#ef4444'}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${(MARKET_SENTIMENT.overall / 100) * 188.5} 251.3`}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-5xl font-bold ${getScoreColor(MARKET_SENTIMENT.overall)}`}>
                {MARKET_SENTIMENT.overall}
              </span>
              <span className="text-sm text-zinc-400 mt-1">Bullish</span>
            </div>
          </div>

          {/* Stats */}
          <div className="flex-1 grid grid-cols-2 gap-4">
            <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-500 text-sm mb-1">
                <AlertTriangle size={14} />
                Fear & Greed
              </div>
              <p className="text-2xl font-bold">{MARKET_SENTIMENT.fearGreedIndex}</p>
              <p className={`text-sm font-medium ${
                MARKET_SENTIMENT.fearGreedIndex > 75 ? 'text-green-400' : 
                MARKET_SENTIMENT.fearGreedIndex > 50 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {MARKET_SENTIMENT.fearGreedLabel}
              </p>
            </div>

            <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-500 text-sm mb-1">
                <Zap size={14} />
                VIX (Fear)
              </div>
              <p className="text-2xl font-bold">{MARKET_SENTIMENT.vix}</p>
              <p className={`text-sm font-medium flex items-center gap-1 ${
                MARKET_SENTIMENT.vix < 20 ? 'text-green-400' : 'text-yellow-400'
              }`}>
                {getTrendIcon(MARKET_SENTIMENT.vixChange > 0 ? 'up' : 'down')}
                {Math.abs(MARKET_SENTIMENT.vixChange)}
              </p>
            </div>

            <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-500 text-sm mb-1">
                <BarChart3 size={14} />
                Put/Call Ratio
              </div>
              <p className="text-2xl font-bold">{MARKET_SENTIMENT.putCallRatio}</p>
              <p className={`text-sm font-medium ${
                MARKET_SENTIMENT.putCallRatio < 1 ? 'text-green-400' : 'text-red-400'
              }`}>
                {MARKET_SENTIMENT.putCallRatio < 1 ? 'More Calls 📈' : 'More Puts 📉'}
              </p>
            </div>

            <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-500 text-sm mb-1">
                <Users size={14} />
                MM Positioning
              </div>
              <p className="text-2xl font-bold">{MARKET_SENTIMENT.mmExposure}%</p>
              <p className="text-sm font-medium text-zinc-400">
                {MARKET_SENTIMENT.mmPositioning === 'net-long' ? 'Net Long' : 'Net Short'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-zinc-950 rounded-lg border border-zinc-800 w-fit">
        {[
          { id: 'overview', label: 'Overview', icon: Activity },
          { id: 'stocks', label: 'By Stock', icon: TrendingUp },
          { id: 'sectors', label: 'By Sector', icon: Globe },
          { id: 'timeline', label: 'Timeline', icon: BarChart3 },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.id ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="grid md:grid-cols-2 gap-6">
          {/* Retail vs Institutional */}
          <div className="card-sleek p-5">
            <h4 className="font-medium text-zinc-400 mb-4">Retail vs Institutional Sentiment</h4>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Retail Investors</span>
                  <span className="font-bold">{MARKET_SENTIMENT.retailSentiment}%</span>
                </div>
                <div className="h-3 bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-500 rounded-full transition-all"
                    style={{ width: `${MARKET_SENTIMENT.retailSentiment}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Institutions</span>
                  <span className="font-bold">{MARKET_SENTIMENT.institutionalSentiment}%</span>
                </div>
                <div className="h-3 bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-purple-500 rounded-full transition-all"
                    style={{ width: `${MARKET_SENTIMENT.institutionalSentiment}%` }}
                  />
                </div>
              </div>
            </div>
            <p className="text-xs text-zinc-500 mt-4">
              Institutions are {MARKET_SENTIMENT.institutionalSentiment > MARKET_SENTIMENT.retailSentiment ? 'more' : 'less'} bullish than retail
            </p>
          </div>

          {/* Sentiment Breakdown */}
          <div className="card-sleek p-5">
            <h4 className="font-medium text-zinc-400 mb-4">Sentiment Sources</h4>
            <div className="space-y-3">
              {[
                { name: 'Social Media', score: 72, icon: MessageCircle },
                { name: 'News Media', score: 68, icon: Newspaper },
                { name: 'Analyst Ratings', score: 76, icon: Users },
                { name: 'Insider Activity', score: 71, icon: TrendingUp },
              ].map(source => (
                <div key={source.name} className="flex items-center gap-3">
                  <source.icon size={16} className="text-zinc-500" />
                  <span className="text-sm flex-1">{source.name}</span>
                  <div className="w-24 h-2 bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${getScoreBg(source.score)}`}
                      style={{ width: `${source.score}%` }}
                    />
                  </div>
                  <span className={`text-sm font-bold w-10 text-right ${getScoreColor(source.score)}`}>
                    {source.score}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'stocks' && (
        <div className="grid gap-4">
          {Object.entries(STOCK_SENTIMENT).map(([ticker, data]) => (
            <div 
              key={ticker}
              className="card-sleek p-5 cursor-pointer hover:border-zinc-600 transition-all"
              onClick={() => setSelectedStock({ ticker, ...data })}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-center w-16">
                    <span className={`text-3xl font-bold ${getScoreColor(data.overall)}`}>
                      {data.overall}
                    </span>
                    <p className="text-xs text-zinc-500 mt-1">Score</p>
                  </div>
                  <div>
                    <h4 className="font-mono font-bold text-xl">{ticker}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        data.trend === 'very-bullish' ? 'bg-green-950 text-green-400' :
                        data.trend === 'bullish' ? 'bg-green-900/50 text-green-400' :
                        data.trend === 'bearish' ? 'bg-red-900/50 text-red-400' :
                        'bg-yellow-900/50 text-yellow-400'
                      }`}>
                        {data.trend.replace('-', ' ').toUpperCase()}
                      </span>
                      <span className="text-xs text-zinc-500">
                        {data.mentions24h.toLocaleString()} mentions (+{data.mentionsChange}%)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="hidden md:grid grid-cols-4 gap-4 text-center">
                  <div>
                    <p className="text-xs text-zinc-500 mb-1">Social</p>
                    <p className={`font-bold ${getScoreColor(data.social)}`}>{data.social}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 mb-1">News</p>
                    <p className={`font-bold ${getScoreColor(data.news)}`}>{data.news}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 mb-1">Analyst</p>
                    <p className={`font-bold ${getScoreColor(data.analyst)}`}>{data.analyst}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 mb-1">Insider</p>
                    <p className={`font-bold ${getScoreColor(data.insider)}`}>{data.insider}%</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-zinc-800">
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-zinc-500">Sentiment split:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 h-2 bg-zinc-800 rounded-full overflow-hidden flex">
                      <div className="h-full bg-green-500" style={{ width: `${data.bullishPosts}%` }} />
                      <div className="h-full bg-red-500" style={{ width: `${data.bearishPosts}%` }} />
                      <div className="h-full bg-zinc-500" style={{ width: `${data.neutralPosts}%` }} />
                    </div>
                  </div>
                  <span className="text-green-400">{data.bullishPosts}% Bull</span>
                  <span className="text-red-400">{data.bearishPosts}% Bear</span>
                  <span className="text-zinc-500">{data.neutralPosts}% Neutral</span>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {data.keywords.map(keyword => (
                    <span key={keyword} className="px-2 py-1 bg-zinc-950 rounded text-xs text-zinc-400">
                      #{keyword}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'sectors' && (
        <div className="grid md:grid-cols-2 gap-4">
          {SECTOR_SENTIMENT.map(sector => (
            <div key={sector.name} className="card-sleek p-5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold">{sector.name}</h4>
                <div className="flex items-center gap-2">
                  {getTrendIcon(sector.trend)}
                  <span className={`font-bold ${getScoreColor(sector.score)}`}>{sector.score}</span>
                </div>
              </div>
              <div className="h-3 bg-zinc-800 rounded-full overflow-hidden mb-3">
                <div 
                  className={`h-full rounded-full ${getScoreBg(sector.score)}`}
                  style={{ width: `${sector.score}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className={`${sector.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {sector.change >= 0 ? '+' : ''}{sector.change} today
                </span>
                <span className="text-zinc-500 capitalize">Volume: {sector.volume}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'timeline' && (
        <div className="card-sleek p-6">
          <h4 className="font-medium text-zinc-400 mb-4">Intraday Sentiment Timeline</h4>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-zinc-800 -translate-y-1/2" />
            
            <div className="grid grid-cols-6 gap-2">
              {NEWS_SENTIMENT_TIMELINE.map((point, idx) => (
                <div key={idx} className="text-center relative">
                  <div 
                    className={`w-4 h-4 rounded-full mx-auto mb-2 relative z-10 border-2 border-zinc-900 ${
                      point.sentiment >= 70 ? 'bg-green-500' : point.sentiment >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                  />
                  <p className="text-xs text-zinc-500">{point.time}</p>
                  <p className={`text-sm font-bold ${getScoreColor(point.sentiment)}`}>
                    {point.sentiment}
                  </p>
                  <p className="text-xs text-zinc-600">{point.volume} posts</p>
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-zinc-500 mt-4 text-center">
            Sentiment improved throughout the trading day, peaking at 2:30 PM
          </p>
        </div>
      )}

      {/* Stock Detail Modal */}
      {selectedStock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedStock(null)}>
          <div className="bg-zinc-900 rounded-2xl border border-zinc-700 max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="font-mono font-bold text-2xl">{selectedStock.ticker}</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  selectedStock.overall >= 70 ? 'bg-green-950 text-green-400' :
                  selectedStock.overall >= 50 ? 'bg-yellow-950 text-yellow-400' :
                  'bg-red-950 text-red-400'
                }`}>
                  {getTrendLabel(selectedStock.overall)}
                </span>
              </div>
              <button onClick={() => setSelectedStock(null)} className="p-2 hover:bg-zinc-800 rounded-lg">
                <span className="text-2xl">×</span>
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Score Breakdown */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Social Media', score: selectedStock.social },
                  { label: 'News Coverage', score: selectedStock.news },
                  { label: 'Analyst Ratings', score: selectedStock.analyst },
                  { label: 'Insider Activity', score: selectedStock.insider },
                ].map(item => (
                  <div key={item.label} className="p-4 bg-zinc-950 rounded-xl">
                    <p className="text-sm text-zinc-500 mb-2">{item.label}</p>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${getScoreBg(item.score)}`}
                          style={{ width: `${item.score}%` }}
                        />
                      </div>
                      <span className={`font-bold ${getScoreColor(item.score)}`}>{item.score}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Mentions */}
              <div className="p-4 bg-zinc-950 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-zinc-400">24h Social Mentions</span>
                  <span className="text-2xl font-bold">{selectedStock.mentions24h.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp size={16} className="text-green-400" />
                  <span className="text-green-400">+{selectedStock.mentionsChange}%</span>
                  <span className="text-zinc-500">vs previous 24h</span>
                </div>
              </div>

              {/* Keywords */}
              <div>
                <h4 className="font-medium text-zinc-400 mb-3">Trending Keywords</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedStock.keywords.map((keyword, idx) => (
                    <span 
                      key={keyword} 
                      className="px-3 py-1.5 bg-zinc-800 rounded-lg text-sm"
                      style={{ opacity: 1 - (idx * 0.1) }}
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>

              {/* Momentum */}
              <div className="p-4 bg-zinc-950 rounded-xl">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Momentum</span>
                  <span className={`font-bold ${
                    selectedStock.momentum === 'strong' ? 'text-green-400' :
                    selectedStock.momentum === 'accelerating' ? 'text-blue-400' :
                    selectedStock.momentum === 'weak' ? 'text-red-400' :
                    'text-yellow-400'
                  }`}>
                    {selectedStock.momentum.charAt(0).toUpperCase() + selectedStock.momentum.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
