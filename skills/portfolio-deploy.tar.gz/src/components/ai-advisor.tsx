"use client"

import { useState, useEffect } from "react"
import { Send, Bot, TrendingUp, Sparkles, Target, Zap, Lightbulb } from "lucide-react"

const VPS_API_URL = "http://65.109.11.40:3001"

// Investment recommendations based on current holdings
const RECOMMENDATIONS = {
  sectors: [
    {
      name: "Defense & Aerospace",
      match: "Complements your ONDS position",
      stocks: [
        { ticker: "AVAV", name: "AeroVironment", thesis: "Drones & unmanned systems", price: "$215.40", conviction: "High" },
        { ticker: "KTOS", name: "Kratos Defense", thesis: "Hypersonics & AI warfare", price: "$28.15", conviction: "Medium" },
        { ticker: "LMT", name: "Lockheed Martin", thesis: "Stable defense giant", price: "$485.20", conviction: "High" }
      ],
      reasoning: "You have 26% in ONDS. Adding established defense names diversifies within the sector while maintaining theme exposure."
    },
    {
      name: "AI & Semiconductors",
      match: "NVDA ecosystem expansion",
      stocks: [
        { ticker: "AMD", name: "AMD", thesis: "GPU competition heating up", price: "$118.50", conviction: "High" },
        { ticker: "ASML", name: "ASML", thesis: "Monopoly on EUV lithography", price: "$765.40", conviction: "Very High" },
        { ticker: "TSM", name: "Taiwan Semi", thesis: "NVDA's manufacturer", price: "$185.60", conviction: "High" },
        { ticker: "ARM", name: "ARM Holdings", thesis: "AI chip architecture", price: "$142.30", conviction: "Medium" }
      ],
      reasoning: "You have 64% in NVDA. These are picks/shovels plays in the AI infrastructure buildout."
    },
    {
      name: "Space & Satellite",
      match: "High-growth frontier",
      stocks: [
        { ticker: "RKLB", name: "Rocket Lab", thesis: "Space infrastructure", price: "$72.45", conviction: "High" },
        { ticker: "ASTS", name: "AST SpaceMobile", thesis: "Satellite-to-cell", price: "$28.90", conviction: "Speculative" },
        { ticker: "PL", name: "Planet Labs", thesis: "Earth observation data", price: "$4.85", conviction: "Medium" }
      ],
      reasoning: "Adjacent to defense theme. High-risk/high-reward sector for 5-10% allocation."
    },
    {
      name: "Index ETFs",
      match: "Reduce concentration risk",
      stocks: [
        { ticker: "VOO", name: "S&P 500 ETF", thesis: "Already own - buy more!", price: "$638.83", conviction: "Very High" },
        { ticker: "QQQ", name: "Nasdaq 100", thesis: "Tech-heavy diversification", price: "$520.30", conviction: "High" },
        { ticker: "SMH", name: "Semiconductor ETF", thesis: "Instead of single chip stocks", price: "$285.40", conviction: "High" }
      ],
      reasoning: "You need to reduce NVDA from 64% to ~35%. ETFs give exposure without single-stock risk."
    }
  ],
  strategy: {
    current: { tech: 64, defense: 26, biotech: 4, index: 5, international: 0, realestate: 0 },
    target: { tech: 35, defense: 20, biotech: 5, index: 25, international: 10, realestate: 5 }
  }
}

const AVATAR = "🦞"
const USER_AVATAR = "👤"

interface Message {
  role: "ai" | "user"
  content: string
  avatar: string
}

export function AIAdvisor() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [portfolio, setPortfolio] = useState(null)

  useEffect(() => {
    fetch(`${VPS_API_URL}/api/portfolio`)
      .then(r => r.json())
      .then(data => {
        setPortfolio(data)
        const greeting = generateGreeting(data)
        setMessages([{ role: "ai", content: greeting, avatar: AVATAR }])
      })
  }, [])

  const generateGreeting = (data) => {
    const pnl = data?.pnl || 0
    const status = pnl >= 0 ? "profitable" : "down"
    return `👋 Hey Kai! Your portfolio is currently **${status}** $${Math.abs(pnl).toFixed(0)}.\n\n` +
      `📊 **Current Allocation Issues:**\n` +
      `• NVDA: 64% ⚠️ (Too concentrated!)\n` +
      `• ONDS: 26% ✅ (Good exposure)\n` +
      `• Index: 5% ⚠️ (Too low)\n\n` +
      `💡 **Ask me:**\n` +
      `• "recommendations" - Stocks to buy\n` +
      `• "rebalance" - How to fix allocation\n` +
      `• "risk" - Portfolio risk analysis\n` +
      `• Any stock ticker for analysis`
  }

  const handleSend = async () => {
    if (!input.trim()) return
    const userMsg = input
    setMessages(prev => [...prev, { role: "user", content: userMsg, avatar: USER_AVATAR }])
    setInput("")
    setLoading(true)

    setTimeout(() => {
      const lower = userMsg.toLowerCase()
      let response = ""

      if (lower.includes("recommend") || lower.includes("buy") || lower.includes("invest")) {
        response = generateRecommendations()
      } else if (lower.includes("rebalance") || lower.includes("allocation")) {
        response = generateRebalanceStrategy()
      } else if (lower.includes("risk")) {
        response = generateRiskAnalysis()
      } else if (['nvda', 'onds', 'sls', 'voo'].some(s => lower.includes(s))) {
        response = analyzeStock(lower)
      } else {
        response = `🤔 I'm not sure what you mean. Try:\n\n` +
          `• "recommendations" - Investment ideas\n` +
          `• "rebalance" - Fix your allocation\n` +
          `• "risk" - Risk assessment\n` +
          `• Stock ticker like "NVDA"`
      }

      setMessages(prev => [...prev, { role: "ai", content: response, avatar: AVATAR }])
      setLoading(false)
    }, 800)
  }

  const generateRecommendations = () => {
    let recs = `🎯 **PERSONALIZED RECOMMENDATIONS**\n\n`
    
    RECOMMENDATIONS.sectors.forEach((sector, idx) => {
      recs += `${idx + 1}. **${sector.name}**\n`
      recs += `   ${sector.match}\n\n`
      sector.stocks.forEach(stock => {
        const convictionEmoji = stock.conviction === "Very High" ? "🔥" : stock.conviction === "High" ? "⭐" : "📊"
        recs += `   ${convictionEmoji} **${stock.ticker}** - ${stock.name}\n`
        recs += `      💰 ${stock.price} | ${stock.thesis}\n`
      })
      recs += `\n   💭 *${sector.reasoning}*\n\n`
    })

    recs += `---\n📈 **Implementation Plan:**\n`
    recs += `1. Sell 30% of NVDA (reduce to ~35%)\n`
    recs += `2. Add ASML or TSM (10% international)\n`
    recs += `3. Increase VOO to 20% total\n`
    recs += `4. Add 1 defense name (5% LMT/AVAV)\n`
    recs += `5. Optional: 5% RKLB for space exposure`

    return recs
  }

  const generateRebalanceStrategy = () => {
    return `⚖️ **REBALANCING STRATEGY**\n\n` +
      `**Current → Target:**\n` +
      `• Tech: 64% → 35% (Sell NVDA)\n` +
      `• Defense: 26% → 20% (Hold ONDS)\n` +
      `• Index: 5% → 25% (Buy more VOO)\n` +
      `• International: 0% → 10% (Add ASML/TSM)\n` +
      `• Real Estate: 0% → 5% (Add VNQ)\n\n` +
      `🎯 **Step-by-Step:**\n` +
      `1. Sell ~20 NVDA shares → $3,800 cash\n` +
      `2. Buy $2,000 more VOO\n` +
      `3. Buy $1,500 ASML (5 shares)\n` +
      `4. Buy $300 AVAV or LMT\n\n` +
      `⚠️ **Tax Considerations:**\n` +
      `Your NVDA position is up 3.8%. Consider:\n` +
      `• Hold in tax-advantaged account\n` +
      `• Tax-loss harvest SLS (-13.7%)\n` +
      `• Spread sales across tax years`
  }

  const generateRiskAnalysis = () => {
    return `⚠️ **PORTFOLIO RISK ANALYSIS**\n\n` +
      `🔴 **HIGH RISKS:**\n` +
      `• 64% NVDA - Single stock concentration\n` +
      `• 90% in 2 stocks (NVDA+ONDS)\n` +
      `• No international diversification\n` +
      `• No fixed income/bonds\n\n` +
      `🟡 **MEDIUM RISKS:**\n` +
      `• ONDS pre-profitability\n` +
      `• SLS biotech volatility\n` +
      `• All positions in growth stocks\n\n` +
      `🟢 **RISK MITIGATION:**\n` +
      `• Add 25% index ETFs (VOO/QQQ)\n` +
      `• Add 10% international (ASML/TSM)\n` +
      `• Consider 5% bonds (BND)\n` +
      `• Set stop-losses on NVDA at $165\n\n` +
      `📊 **Current Risk Score: 8.5/10**\n` +
      `Target Risk Score: 6/10`
  }

  const analyzeStock = (query) => {
    const stocks = {
      nvda: `📊 **NVIDIA (NVDA) Analysis**\n\n` +
        `💰 Price: $189.92 (+2.54%)\n` +
        `🎯 Target: $250 (+31% upside)\n` +
        `⭐ Rating: STRONG BUY\n\n` +
        `**Strengths:**\n` +
        `• AI infrastructure leader\n` +
        `• Blackwell chip demand\n` +
        `• 39 analyst BUY ratings\n\n` +
        `**Concerns:**\n` +
        `• 64% of your portfolio!\n` +
        `• High valuation (P/E 65x)\n` +
        `• China export restrictions\n\n` +
        `💡 **Action:** Trim to 35% position`,
      
      onds: `📊 **ONDAS (ONDS) Analysis**\n\n` +
        `💰 Price: $10.33 (+6.60%) 🚀\n` +
        `🎯 Target: $18.38 (+78% upside)\n` +
        `⭐ Rating: BUY\n\n` +
        `**Recent Catalysts:**\n` +
        `• $30M Israel contract\n` +
        `• Asia-Pacific defense deal\n` +
        `• 26% position size is good\n\n` +
        `**Risks:**\n` +
        `• Still losing money\n` +
        `• May need capital raise\n` +
        `• Execution risk on contracts\n\n` +
        `💡 **Action:** HOLD, add on dips to $8`,

      sls: `📊 **SELLAS (SLS) Analysis**\n\n` +
        `💰 Price: $3.72 (-0.40%)\n` +
        `🎯 Target: $8.50 (+128% upside)\n` +
        `⭐ Rating: HOLD\n\n` +
        `**Thesis:**\n` +
        `• Phase 2 trials pending\n` +
        `• Only 4% of portfolio\n` +
        `• High risk/reward biotech\n\n` +
        `💡 **Action:** Keep small position`,

      voo: `📊 **VOO (S&P 500 ETF) Analysis**\n\n` +
        `💰 Price: $638.83 (+0.56%)\n` +
        `🎯 Target: $700 (+10% upside)\n` +
        `⭐ Rating: BUY MORE\n\n` +
        `**Why Increase:**\n` +
        `• Only 5% of portfolio (too low!)\n` +
        `• Reduces concentration risk\n` +
        `• S&P 500 at all-time highs\n` +
        `• Low 0.03% expense ratio\n\n` +
        `💡 **Action:** Increase to 25%`
    }

    for (const [key, value] of Object.entries(stocks)) {
      if (query.includes(key)) return value
    }
    return "Stock not found. Try NVDA, ONDS, SLS, or VOO."
  }

  return (
    <div className="card-sleek h-[500px] flex flex-col overflow-hidden animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-r from-zinc-900 to-zinc-950 p-4 border-b border-zinc-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center animate-pulse-subtle">
              <span className="text-2xl">{AVATAR}</span>
            </div>
            <div>
              <h3 className="font-bold text-white">Portfolio AI</h3>
              <p className="text-xs text-zinc-500 flex items-center gap-1">
                <Sparkles size={10} className="text-yellow-500" />
                Personalized recommendations
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 px-2 py-1 bg-green-950/50 rounded-full border border-green-900/50">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-400 font-medium">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-black">
        {messages.map((msg, idx) => (
          <div 
            key={idx} 
            className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""} animate-slide-in`}
            style={{ animationDelay: `${idx * 0.1}s` }}
          >
            {msg.role === "ai" && (
              <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center flex-shrink-0 border border-zinc-700">
                <span className="text-lg">{msg.avatar}</span>
              </div>
            )}
            <div className={`max-w-[85%] p-3 rounded-2xl whitespace-pre-line text-sm leading-relaxed ${
              msg.role === "user" 
                ? "bg-white text-black font-medium" 
                : "bg-zinc-900 text-zinc-100 border border-zinc-800"
            }`}>
              {msg.content.split('**').map((part, i) => 
                i % 2 === 0 ? part : <strong key={i} className="text-white">{part}</strong>
              )}
            </div>
            {msg.role === "user" && (
              <div className="w-8 h-8 bg-zinc-700 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm">{msg.avatar}</span>
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center">
              <span className="text-lg">{AVATAR}</span>
            </div>
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-2 h-2 bg-zinc-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-2 bg-zinc-950 border-t border-zinc-900 flex gap-2 overflow-x-auto">
        {['Recommendations', 'Rebalance', 'Risk'].map(action => (
          <button
            key={action}
            onClick={() => {
              setInput(action.toLowerCase())
              handleSend()
            }}
            className="flex items-center gap-1 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 rounded-full text-xs font-medium text-zinc-300 transition-all hover:scale-105 whitespace-nowrap border border-zinc-800"
          >
            {action === 'Recommendations' && <Lightbulb size={12} />}
            {action === 'Rebalance' && <Target size={12} />}
            {action === 'Risk' && <Zap size={12} />}
            {action}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 bg-zinc-950 border-t border-zinc-800">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask about recommendations, rebalancing, risk, or any stock..."
            className="input-sleek flex-1"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="btn-primary px-4 py-2 rounded-lg flex items-center justify-center"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  )
}
