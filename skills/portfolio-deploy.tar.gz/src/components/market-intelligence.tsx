"use client"

import { useState, useEffect } from "react"
import { 
  Newspaper, TrendingUp, Users, Eye, ArrowUpRight, ArrowDownRight,
  Activity, AlertCircle, Twitter, MessageCircle, BarChart3
} from "lucide-react"

// Simulated real-time news & market data
const MARKET_NEWS = [
  {
    id: 1,
    time: "2 min ago",
    source: "Bloomberg",
    headline: "NVIDIA Blackwell Chip Demand 'Exceeding Supply by 3x'",
    ticker: "NVDA",
    sentiment: "bullish",
    impact: "high",
    category: "Earnings"
  },
  {
    id: 2,
    time: "15 min ago",
    source: "Reuters",
    headline: "Ondas Secures Additional $15M Follow-on Contract from Israel",
    ticker: "ONDS",
    sentiment: "bullish",
    impact: "high",
    category: "Contracts"
  },
  {
    id: 3,
    time: "32 min ago",
    source: "CNBC",
    headline: "Defense Sector Rally Continues on Geopolitical Tensions",
    ticker: "DEFENSE",
    sentiment: "bullish",
    impact: "medium",
    category: "Sector"
  },
  {
    id: 4,
    time: "1 hour ago",
    source: "WSJ",
    headline: "Taiwan Semi to Increase NVDA Chip Production by 50% in Q2",
    ticker: "TSM",
    sentiment: "bullish",
    impact: "high",
    category: "Supply Chain"
  },
  {
    id: 5,
    time: "2 hours ago",
    source: "Financial Times",
    headline: "Biotech Sector Under Pressure Ahead of FDA Decisions",
    ticker: "SLS",
    sentiment: "bearish",
    impact: "medium",
    category: "Sector"
  }
]

const WHALE_ACTIVITY = [
  {
    id: 1,
    entity: "Cathie Wood (ARKK)",
    action: "BUY",
    ticker: "NVDA",
    shares: "125,000",
    value: "$23.7M",
    date: "Today",
    confidence: "very-high",
    note: "Added to ARKK flagship fund"
  },
  {
    id: 2,
    entity: "BlackRock",
    action: "BUY",
    ticker: "ONDS",
    shares: "450,000",
    value: "$4.6M",
    date: "Yesterday",
    confidence: "high",
    note: "Increased position post-contract"
  },
  {
    id: 3,
    entity: "Renaissance Technologies",
    action: "SELL",
    ticker: "NVDA",
    shares: "85,000",
    value: "$16.1M",
    date: "2 days ago",
    confidence: "medium",
    note: "Profit-taking after earnings"
  },
  {
    id: 4,
    entity: "Baillie Gifford",
    action: "BUY",
    ticker: "RKLB",
    shares: "2.1M",
    value: "$152M",
    date: "This week",
    confidence: "high",
    note: "Major space infrastructure bet"
  }
]

const INSIDER_TRADING = [
  {
    id: 1,
    name: "Eric Brock",
    role: "CEO",
    ticker: "ONDS",
    action: "BUY",
    shares: 25000,
    price: "$9.85",
    value: "$246,250",
    date: "Feb 8, 2026",
    type: "Form 4",
    significance: "high"
  },
  {
    id: 2,
    name: "Jensen Huang",
    role: "CEO",
    ticker: "NVDA",
    action: "SELL",
    shares: 50000,
    price: "$185.50",
    value: "$9,275,000",
    date: "Feb 5, 2026",
    type: "10b5-1 Plan",
    significance: "medium"
  },
  {
    id: 3,
    name: "Michael Nierenberg",
    role: "CFO",
    ticker: "ONDS",
    action: "BUY",
    shares: 15000,
    price: "$9.90",
    value: "$148,500",
    date: "Feb 7, 2026",
    type: "Form 4",
    significance: "medium"
  }
]

const MARKET_SENTIMENT = {
  overall: 72, // 0-100, higher = more bullish
  vix: 14.2,
  fearGreed: "Greed", // Extreme Fear, Fear, Neutral, Greed, Extreme Greed
  putCallRatio: 0.82,
  mmPositioning: "net-long",
  retailSentiment: 68,
  institutionalSentiment: 74
}

const SOCIAL_SENTIMENT = {
  twitter: { nvda: 78, onds: 82, sls: 45 },
  reddit: { nvda: 75, onds: 68, sls: 52 },
  stocktwits: { nvda: 76, onds: 79, sls: 48 }
}

export function MarketIntelligence() {
  const [activeTab, setActiveTab] = useState('news')
  const [lastUpdate, setLastUpdate] = useState(new Date())

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date())
    }, 60000)
    return () => clearInterval(interval)
  }, [])

  const getSentimentColor = (score) => {
    if (score >= 70) return 'text-green-400'
    if (score >= 50) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getSentimentBg = (score) => {
    if (score >= 70) return 'bg-green-950/50 border-green-800'
    if (score >= 50) return 'bg-yellow-950/50 border-yellow-800'
    return 'bg-red-950/50 border-red-800'
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Sentiment Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card-sleek p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-zinc-500 text-sm">Market Sentiment</span>
            <Activity size={16} className="text-zinc-600" />
          </div>
          <div className="flex items-end gap-2">
            <span className={`text-3xl font-bold ${getSentimentColor(MARKET_SENTIMENT.overall)}`}>
              {MARKET_SENTIMENT.overall}
            </span>
            <span className="text-sm text-zinc-500 mb-1">/100</span>
          </div>
          <p className={`text-sm font-medium mt-1 ${getSentimentColor(MARKET_SENTIMENT.overall)}`}>
            {MARKET_SENTIMENT.fearGreed}
          </p>
        </div>

        <div className="card-sleek p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-zinc-500 text-sm">VIX (Fear Index)</span>
            <AlertCircle size={16} className="text-zinc-600" />
          </div>
          <div className="flex items-end gap-2">
            <span className={`text-3xl font-bold ${MARKET_SENTIMENT.vix < 20 ? 'text-green-400' : 'text-yellow-400'}`}>
              {MARKET_SENTIMENT.vix}
            </span>
          </div>
          <p className={`text-sm font-medium mt-1 ${MARKET_SENTIMENT.vix < 20 ? 'text-green-400' : 'text-yellow-400'}`}>
            {MARKET_SENTIMENT.vix < 20 ? 'Low Fear' : 'Elevated Fear'}
          </p>
        </div>

        <div className="card-sleek p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-zinc-500 text-sm">Put/Call Ratio</span>
            <BarChart3 size={16} className="text-zinc-600" />
          </div>
          <div className="flex items-end gap-2">
            <span className={`text-3xl font-bold ${MARKET_SENTIMENT.putCallRatio < 1 ? 'text-green-400' : 'text-red-400'}`}>
              {MARKET_SENTIMENT.putCallRatio}
            </span>
          </div>
          <p className={`text-sm font-medium mt-1 ${MARKET_SENTIMENT.putCallRatio < 1 ? 'text-green-400' : 'text-red-400'}`}>
            {MARKET_SENTIMENT.putCallRatio < 1 ? 'More Calls (Bullish)' : 'More Puts (Bearish)'}
          </p>
        </div>

        <div className="card-sleek p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-zinc-500 text-sm">Institutional</span>
            <Users size={16} className="text-zinc-600" />
          </div>
          <div className="flex items-end gap-2">
            <span className={`text-3xl font-bold ${getSentimentColor(MARKET_SENTIMENT.institutionalSentiment)}`}>
              {MARKET_SENTIMENT.institutionalSentiment}
            </span>
            <span className="text-sm text-zinc-500 mb-1">/100</span>
          </div>
          <p className="text-sm font-medium mt-1 text-zinc-400">
            {MARKET_SENTIMENT.mmPositioning === 'net-long' ? 'Net Long 📈' : 'Net Short 📉'}
          </p>
        </div>
      </div>

      {/* Social Sentiment */}
      <div className="card-sleek p-6">
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <MessageCircle size={20} className="text-blue-400" />
          Social Media Sentiment
        </h3>
        <div className="grid grid-cols-3 gap-4">
          {Object.entries(SOCIAL_SENTIMENT).map(([platform, stocks]) => (
            <div key={platform} className="space-y-3">
              <h4 className="font-medium text-zinc-400 capitalize text-sm">{platform}</h4>
              {Object.entries(stocks).map(([ticker, score]) => (
                <div key={ticker} className="flex items-center justify-between">
                  <span className="font-mono font-bold">{ticker.toUpperCase()}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${getSentimentColor(score)}`}
                        style={{ width: `${score}%` }}
                      />
                    </div>
                    <span className={`text-sm font-medium ${getSentimentColor(score)}`}>
                      {score}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-zinc-950 rounded-lg border border-zinc-800 w-fit">
        {[
          { id: 'news', label: 'News', icon: Newspaper },
          { id: 'whales', label: 'Whale Activity', icon: Eye },
          { id: 'insider', label: 'Insider Trades', icon: Users },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.id 
                ? 'bg-zinc-800 text-white' 
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <tab.icon size={14} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* News Tab */}
      {activeTab === 'news' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm text-zinc-500">
            <span>Latest market-moving news</span>
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              Live updates
            </span>
          </div>
          {MARKET_NEWS.map((news, idx) => (
            <div 
              key={news.id} 
              className="card-sleek p-4 hover:border-zinc-600 transition-all cursor-pointer group animate-slide-in"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-zinc-500">{news.time}</span>
                    <span className="text-xs px-2 py-0.5 bg-zinc-800 rounded text-zinc-400">{news.source}</span>
                    <span className={`text-xs px-2 py-0.5 rounded font-medium ${
                      news.impact === 'high' ? 'bg-red-950 text-red-400' : 'bg-zinc-800 text-zinc-400'
                    }`}>
                      {news.impact.toUpperCase()} IMPACT
                    </span>
                  </div>
                  <h4 className="font-bold text-white group-hover:text-blue-400 transition-colors">
                    {news.headline}
                  </h4>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="font-mono font-bold text-sm">{news.ticker}</span>
                    <span className={`text-xs flex items-center gap-1 ${
                      news.sentiment === 'bullish' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {news.sentiment === 'bullish' ? <TrendingUp size={12} /> : <TrendingUp size={12} className="rotate-180" />}
                      {news.sentiment.toUpperCase()}
                    </span>
                  </div>
                </div>
                <ArrowUpRight size={20} className="text-zinc-600 group-hover:text-white transition-colors" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Whale Activity Tab */}
      {activeTab === 'whales' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm text-zinc-500">
            <span>Institutional & smart money moves</span>
            <span className="text-zinc-400">Last 7 days</span>
          </div>
          {WHALE_ACTIVITY.map((whale, idx) => (
            <div 
              key={whale.id} 
              className="card-sleek p-4 animate-slide-in"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    whale.action === 'BUY' ? 'bg-green-950' : 'bg-red-950'
                  }`}>
                    <span className="text-lg">{whale.action === 'BUY' ? '🐋' : '🐻'}</span>
                  </div>
                  <div>
                    <h4 className="font-bold">{whale.entity}</h4>
                    <p className="text-sm text-zinc-500">{whale.date} • {whale.note}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 justify-end">
                    <span className={`font-bold ${whale.action === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>
                      {whale.action}
                    </span>
                    <span className="font-mono font-bold">{whale.ticker}</span>
                  </div>
                  <p className="text-sm text-zinc-400">{whale.shares} shares • {whale.value}</p>
                  <div className="flex items-center gap-1 mt-1 justify-end">
                    <span className="text-xs text-zinc-500">Confidence:</span>
                    <div className="flex gap-0.5">
                      {[1,2,3].map(i => (
                        <div 
                          key={i} 
                          className={`w-2 h-2 rounded-full ${
                            i <= (whale.confidence === 'very-high' ? 3 : whale.confidence === 'high' ? 2 : 1) 
                              ? 'bg-blue-400' : 'bg-zinc-700'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Insider Trading Tab */}
      {activeTab === 'insider' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm text-zinc-500">
            <span>C-suite & director transactions</span>
            <span className="text-zinc-400">Form 4 Filings</span>
          </div>
          {INSIDER_TRADING.map((trade, idx) => (
            <div 
              key={trade.id} 
              className={`card-sleek p-4 border-l-4 ${
                trade.action === 'BUY' ? 'border-l-green-500' : 'border-l-red-500'
              } animate-slide-in`}
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-900 rounded-lg flex flex-col items-center justify-center border border-zinc-800">
                    <span className="text-xs text-zinc-500">{trade.name.charAt(0)}</span>
                    <span className="text-xs text-zinc-600">{trade.name.split(' ').pop().charAt(0)}</span>
                  </div>
                  <div>
                    <h4 className="font-bold">{trade.name}</h4>
                    <p className="text-sm text-zinc-500">{trade.role} • {trade.ticker}</p>
                    <p className="text-xs text-zinc-600 mt-1">{trade.type} • {trade.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`flex items-center gap-2 justify-end ${trade.action === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>
                    {trade.action === 'BUY' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                    <span className="font-bold">{trade.action}</span>
                  </div>
                  <p className="text-sm font-mono mt-1">{trade.shares.toLocaleString()} @ {trade.price}</p>
                  <p className="text-sm text-zinc-400">${trade.value}</p>
                  {trade.significance === 'high' && (
                    <span className="inline-block mt-1 px-2 py-0.5 bg-yellow-950 text-yellow-400 rounded text-xs">
                      High Significance
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
