"use client"

import { useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, LineChart, Line, PieChart, Pie, Cell } from 'recharts'

const VPS_API_URL = "http://65.109.11.40:3001"
const USER_NAME = "Kai"
const AVATAR = "🦞"

// Fun color palette - sketch/cartoon vibes
const COLORS = {
  primary: '#FF6B6B',
  secondary: '#4ECDC4', 
  accent: '#FFE66D',
  success: '#95E1D3',
  danger: '#F38181',
  purple: '#C7CEEA',
  orange: '#FECA57'
}

const PIE_COLORS = [COLORS.primary, COLORS.secondary, COLORS.accent, COLORS.purple]

export function PortfolioChart() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState('bars') // 'bars', 'pie', 'line'
  const [timeRange, setTimeRange] = useState('1D')

  const fetchData = async () => {
    try {
      const res = await fetch(`${VPS_API_URL}/api/portfolio`)
      const liveData = await res.json()
      setData(liveData)
    } catch (e) {
      console.error('Fetch error:', e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-4xl animate-bounce">{AVATAR}</div>
        <p className="ml-3 text-lg font-comic">Loading your millions...</p>
      </div>
    )
  }

  if (!data) return null

  const chartData = data.holdings.map(h => ({
    name: h.symbol,
    value: h.value,
    cost: h.cost,
    pnl: h.pnl,
    fullName: h.symbol === 'NVDA' ? 'NVIDIA' : h.symbol === 'ONDS' ? 'Ondas' : h.symbol === 'SLS' ? 'Sellas' : 'S&P 500'
  }))

  const pieData = data.holdings.map(h => ({
    name: h.symbol,
    value: h.value
  }))

  const lineData = [
    { time: '9:30', value: data.totalValue * 0.98 },
    { time: '10:00', value: data.totalValue * 0.99 },
    { time: '11:00', value: data.totalValue * 1.01 },
    { time: '12:00', value: data.totalValue * 0.995 },
    { time: '1:00', value: data.totalValue },
  ]

  return (
    <div className="space-y-4 font-comic">
      {/* Fun Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{AVATAR}</span>
          <div>
            <p className="text-lg font-bold">Hey {USER_NAME}! 👋</p>
            <p className="text-sm text-slate-500">Your money is doing things...</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="relative flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-green-500 border-2 border-black"></span>
          </span>
          <span className="text-sm font-bold bg-green-400 px-2 py-1 rounded-full border-2 border-black">LIVE!</span>
        </div>
      </div>

      {/* BIG Number Display */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-3xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform hover:scale-105 transition-transform">
          <p className="text-lg font-bold text-slate-600">Total Stash 💰</p>
          <p className="text-5xl font-black text-black mt-2">
            ${data.totalValue.toLocaleString(undefined, {maximumFractionDigits: 0})}
          </p>
          <p className="text-sm mt-2 font-bold text-slate-500">You're rich! (sorta)</p>
        </div>
        
        <div className={`p-6 rounded-3xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform hover:scale-105 transition-transform ${data.pnl >= 0 ? 'bg-green-300' : 'bg-red-300'}`}>
          <p className="text-lg font-bold text-black">P&L Today 📈</p>
          <p className={`text-5xl font-black mt-2 ${data.pnl >= 0 ? 'text-green-800' : 'text-red-800'}`}>
            {data.pnl >= 0 ? '+' : ''}${data.pnl.toLocaleString(undefined, {maximumFractionDigits: 0})}
          </p>
          <p className={`text-lg font-bold mt-2 ${data.pnl >= 0 ? 'text-green-700' : 'text-red-700'}`}>
            ({data.pnlPct >= 0 ? '🔥 +' : '🥶 '}{data.pnlPct.toFixed(1)}%)
          </p>
        </div>
      </div>

      {/* View Toggle */}
      <div className="flex gap-2 justify-center">
        {['bars', 'pie', 'line'].map((mode) => (
          <button
            key={mode}
            onClick={() => setViewMode(mode)}
            className={`px-4 py-2 rounded-full border-3 border-black font-bold transform hover:scale-110 transition-transform ${
              viewMode === mode 
                ? 'bg-black text-white shadow-[4px_4px_0px_0px_rgba(100,100,100,1)]' 
                : 'bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]'
            }`}
          >
            {mode === 'bars' && '📊 Bars'}
            {mode === 'pie' && '🥧 Pie'}
            {mode === 'line' && '📈 Line'}
          </button>
        ))}
      </div>

      {/* Chart Container */}
      <div className="bg-white rounded-3xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6">
        <h3 className="text-xl font-black mb-4 text-center">
          {viewMode === 'bars' && "Where Your Money Lives 💵"}
          {viewMode === 'pie' && "The Money Pie 🥧"}
          {viewMode === 'line' && "Today's Rollercoaster 🎢"}
        </h3>
        
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            {viewMode === 'bars' && (
              <BarChart data={chartData}>
                <XAxis dataKey="name" tick={{ fontSize: 14, fontWeight: 'bold' }} />
                <YAxis tickFormatter={(val) => `$${val/1000}k`} tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: '3px solid black',
                    fontWeight: 'bold'
                  }}
                  formatter={(val) => [`$${val.toLocaleString()}`, '']}
                />
                <Bar dataKey="value" fill={COLORS.primary} radius={[12, 12, 0, 0]} stroke="black" strokeWidth={3} />
                <Bar dataKey="cost" fill={COLORS.secondary} radius={[12, 12, 0, 0]} stroke="black" strokeWidth={3} />
              </BarChart>
            )}
            
            {viewMode === 'pie' && (
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  stroke="black"
                  strokeWidth={3}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(val) => `$${val.toLocaleString()}`} />
              </PieChart>
            )}
            
            {viewMode === 'line' && (
              <LineChart data={lineData}>
                <XAxis dataKey="time" tick={{ fontSize: 12, fontWeight: 'bold' }} />
                <YAxis domain={['auto', 'auto']} tickFormatter={(val) => `$${val/1000}k`} />
                <Tooltip formatter={(val) => `$${val.toLocaleString()}`} />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke={COLORS.primary} 
                  strokeWidth={4}
                  dot={{ fill: COLORS.primary, strokeWidth: 3, r: 6 }}
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Stock Cards - Cartoon Style */}
      <div className="grid grid-cols-2 gap-4">
        {data.holdings.map((stock, idx) => (
          <div 
            key={stock.symbol}
            className="bg-white p-4 rounded-2xl border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transform hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer"
            style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }}
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-black">{stock.symbol}</p>
                <p className="text-sm font-bold opacity-75">{chartData[idx]?.fullName}</p>
                <p className="text-xs font-bold mt-1">{stock.shares} shares</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-black">${stock.price.toFixed(2)}</p>
                <p className={`text-lg font-bold ${stock.change >= 0 ? 'text-green-800' : 'text-red-800'}`}>
                  {stock.change >= 0 ? '🚀 +' : '📉 '}{stock.change.toFixed(1)}%
                </p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t-2 border-black border-dashed flex justify-between items-center">
              <span className="font-bold text-sm">P&L:</span>
              <span className={`text-xl font-black ${stock.pnl >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                {stock.pnl >= 0 ? '💚 +' : '💔 '}${stock.pnl.toFixed(0)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Fun Footer */}
      <div className="bg-yellow-300 rounded-2xl border-4 border-black p-4 text-center shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
        <p className="font-bold text-lg">
          {data.pnl >= 0 
            ? "🎉 You're making money! Treat yourself to a coffee! ☕" 
            : "📉 It's just a dip... probably... maybe... HODL! 💎🙌"}
        </p>
      </div>
    </div>
  )
}
