"use client"

import { useState, useEffect } from "react"
import { 
  X, ExternalLink, TrendingUp, TrendingDown, MessageCircle, 
  ThumbsUp, ThumbsDown, Share2, Bookmark, Clock, ChevronRight
} from "lucide-react"

// Interactive news with full articles
const INTERACTIVE_NEWS = [
  {
    id: 1,
    headline: "NVIDIA Blackwell Chip Demand 'Exceeding Supply by 3x' - CEO Jensen Huang",
    summary: "NVIDIA CEO announces unprecedented demand for new Blackwell AI chips, with orders outpacing manufacturing capacity by 300%.",
    fullArticle: `NVIDIA Corporation (NVDA) is experiencing extraordinary demand for its next-generation Blackwell AI chips, with CEO Jensen Huang revealing that current orders are exceeding manufacturing capacity by 300%.

Key Points:
• Data center customers including Microsoft, Google, and Amazon have placed massive pre-orders
• Blackwell delivers 4x performance improvement over Hopper architecture
• Supply constraints expected to persist through Q2 2026
• Company exploring additional manufacturing partnerships

"This is unlike anything we've seen before," Huang stated during the earnings call. "The AI infrastructure buildout is just beginning."

Analysts have raised price targets, with Goldman Sachs maintaining a $280 target citing unmatched competitive moat in AI accelerators.`,
    ticker: "NVDA",
    sentiment: "bullish",
    source: "Bloomberg",
    time: "15 min ago",
    likes: 2847,
    comments: 342,
    relatedTickers: ["AMD", "TSM", "AVGO"]
  },
  {
    id: 2,
    headline: "Ondas Holdings Secures Additional $15M Follow-on Israel Defense Contract",
    summary: "4M Defense subsidiary awarded expansion of demining program along Israel-Syria border, bringing total contract value to $45M.",
    fullArticle: `Ondas Holdings Inc. (ONDS) announced today that its 4M Defense subsidiary has secured a $15 million follow-on contract for the ongoing demining initiative along the Israel-Syria border.

Contract Details:
• Initial contract: $30M (Feb 9, 2026)
• Follow-on award: $15M (Feb 10, 2026)
• Total program value: $45M
• Duration: Extended through 2028
• Scope: Additional 350 acres of demining operations

CEO Eric Brock commented: "This follow-on award demonstrates the confidence our Israeli partners have in 4M's smart demining technology. We're now exploring similar opportunities in other conflict zones."

The news follows the company's recent Asia-Pacific defense contract announced earlier this week, bringing total 2026 defense bookings to over $60M.

Insider Activity: CEO Brock purchased an additional 25,000 shares on Feb 8 at $9.85.`,
    ticker: "ONDS",
    sentiment: "bullish", 
    source: "Reuters",
    time: "32 min ago",
    likes: 892,
    comments: 127,
    relatedTickers: ["AVAV", "KTOS", "LMT"]
  },
  {
    id: 3,
    headline: "ARK Invest Adds $23.7M in NVIDIA Shares Across Flagship Funds",
    summary: "Cathie Wood's ARKK and ARKW funds significantly increased NVDA positions despite recent volatility.",
    fullArticle: `Cathie Wood's ARK Investment Management has significantly increased its NVIDIA (NVDA) holdings, purchasing approximately $23.7 million worth of shares across its flagship ARK Innovation ETF (ARKK) and ARK Next Generation Internet ETF (ARKW).

Purchase Details:
• ARKK: 85,000 shares (~$16.1M)
• ARKW: 40,000 shares (~$7.6M)
• Average purchase price: ~$185.50
• Total position now: ~$145M across all ARK funds

Wood remains bullish on NVIDIA's AI dominance, stating in a recent interview that the company is "the picks and shovels play of the AI revolution." Despite concerns about valuation, ARK's models suggest 30%+ annual growth through 2028.

Other ARK moves today:
• SOLD: $8.2M Tesla (TSLA)
• BOUGHT: $4.1M Rocket Lab (RKLB)`,
    ticker: "NVDA",
    sentiment: "bullish",
    source: "CNBC",
    time: "1 hour ago",
    likes: 1523,
    comments: 289,
    relatedTickers: ["ARKK", "TSLA", "RKLB"]
  }
]

// Detailed stock data
const STOCK_DETAILS = {
  NVDA: {
    company: "NVIDIA Corporation",
    sector: "Technology / Semiconductors",
    employees: "29,600",
    headquarters: "Santa Clara, CA",
    ceo: "Jensen Huang",
    founded: "1993",
    marketCap: "$2.3T",
    peRatio: "65.4",
    forwardPE: "38.2",
    pegRatio: "1.8",
    priceToBook: "52.1",
    revenueGrowth: "+94% YoY",
    profitMargin: "48.9%",
    roe: "69.2%",
    description: "NVIDIA is the world leader in visual computing and AI acceleration. The company's GPUs power data centers, gaming, professional visualization, and autonomous vehicles.",
    keyProducts: ["H100/H200 GPUs", "Blackwell Architecture", "CUDA Platform", "Omniverse"],
    institutionalHolders: ["Vanguard (8.2%)", "BlackRock (7.1%)", "Fidelity (4.3%)"],
    analystRatings: { buy: 39, hold: 3, sell: 1 },
    priceTarget: { low: 195, avg: 250, high: 320 },
    nextEarnings: "Feb 21, 2026",
    insiderActivity: "Mixed - CEO selling via 10b5-1, but ARK buying heavily"
  },
  ONDS: {
    company: "Ondas Holdings Inc.",
    sector: "Industrials / Defense",
    employees: "285",
    headquarters: "West Palm Beach, FL",
    ceo: "Eric Brock",
    founded: "2017",
    marketCap: "$468M",
    peRatio: "N/A",
    forwardPE: "N/A",
    pegRatio: "N/A",
    priceToBook: "7.0",
    revenueGrowth: "+48% YoY",
    profitMargin: "-172%",
    roe: "-17%",
    description: "Ondas Holdings operates through two subsidiaries: Ondas Networks (industrial wireless) and American Robotics (autonomous drones). Recent pivot to defense via 4M Defense subsidiary.",
    keyProducts: ["Optimus Drone", "Smart Demining Systems", "Airobotics Platform", "4M Defense Solutions"],
    institutionalHolders: ["BlackRock (4.2%)", "Vanguard (2.1%)", "Geode (1.8%)"],
    analystRatings: { buy: 3, hold: 1, sell: 0 },
    priceTarget: { low: 12, avg: 18, high: 25 },
    nextEarnings: "Mar 15, 2026",
    insiderActivity: "Bullish - CEO Brock bought 25K shares recently"
  },
  SLS: {
    company: "SELLAS Life Sciences Group",
    sector: "Healthcare / Biotechnology",
    employees: "45",
    headquarters: "New York, NY",
    ceo: "Angelos Stergiou",
    founded: "2012",
    marketCap: "$89M",
    peRatio: "N/A",
    forwardPE: "N/A",
    pegRatio: "N/A",
    priceToBook: "2.1",
    revenueGrowth: "Pre-revenue",
    profitMargin: "N/A",
    roe: "N/A",
    description: "Clinical-stage biopharmaceutical company focused on novel cancer immunotherapies. Lead candidate GPS is in Phase 3 trials for acute myeloid leukemia.",
    keyProducts: ["GPS (galinpepimut-S)", "NeuVax", "GALE-301/401"],
    institutionalHolders: ["BVF Partners (8.5%)", "Boxer Capital (6.2%)"],
    analystRatings: { buy: 2, hold: 2, sell: 0 },
    priceTarget: { low: 5, avg: 8.5, high: 15 },
    nextEarnings: "Mar 28, 2026",
    insiderActivity: "Neutral - No significant recent activity"
  },
  VOO: {
    company: "Vanguard S&P 500 ETF",
    sector: "Index Fund / Large Cap Blend",
    employees: "N/A",
    headquarters: "Malvern, PA",
    ceo: "Mortimer Buckley (Vanguard CEO)",
    founded: "2010",
    marketCap: "$1.1T AUM",
    peRatio: "25.4",
    forwardPE: "21.8",
    pegRatio: "1.6",
    priceToBook: "4.2",
    revenueGrowth: "Tracks S&P 500",
    profitMargin: "Tracks S&P 500",
    roe: "Tracks S&P 500",
    description: "Vanguard S&P 500 ETF seeks to track the performance of the Standard & Poor's 500 Index, which measures the investment return of large-capitalization stocks.",
    keyProducts: ["S&P 500 Index Tracking", "0.03% Expense Ratio", "Dividend Reinvestment"],
    topHoldings: ["Apple (6.8%)", "Microsoft (6.5%)", "NVIDIA (5.2%)", "Amazon (3.6%)"],
    analystRatings: { buy: 45, hold: 0, sell: 0 },
    priceTarget: { low: 620, avg: 700, high: 780 },
    nextEarnings: "N/A - Index Fund",
    insiderActivity: "N/A - Diversified index"
  }
}

// Sentiment tracker
const SENTIMENT_DATA = {
  market: { score: 72, trend: "up", change: +3 },
  sectors: {
    technology: { score: 78, trend: "up", change: +2 },
    defense: { score: 68, trend: "up", change: +5 },
    biotech: { score: 42, trend: "down", change: -4 },
    energy: { score: 55, trend: "flat", change: 0 }
  },
  stocks: {
    NVDA: { 
      social: 82, news: 85, analyst: 92, 
      trend: "very-bullish",
      keywords: ["AI", "chips", "data center", "Jensen Huang"]
    },
    ONDS: { 
      social: 76, news: 88, analyst: 71, 
      trend: "bullish",
      keywords: ["defense", "drones", "Israel contract", "demining"]
    },
    SLS: { 
      social: 38, news: 45, analyst: 52, 
      trend: "neutral",
      keywords: ["biotech", "FDA", "clinical trials", "cancer"]
    },
    VOO: { 
      social: 65, news: 72, analyst: 85, 
      trend: "bullish",
      keywords: ["index", "S&P 500", "diversification", "long-term"]
    }
  }
}

export function InteractiveFeatures() {
  const [selectedNews, setSelectedNews] = useState(null)
  const [selectedStock, setSelectedStock] = useState(null)
  const [activeSentimentTab, setActiveSentimentTab] = useState('stocks')
  const [savedArticles, setSavedArticles] = useState([])
  const [likedArticles, setLikedArticles] = useState([])

  const toggleSave = (id) => {
    setSavedArticles(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const toggleLike = (id) => {
    setLikedArticles(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const getTrendIcon = (trend) => {
    if (trend === 'up' || trend === 'bullish' || trend === 'very-bullish') return <TrendingUp size={16} className="text-green-400" />
    if (trend === 'down' || trend === 'bearish') return <TrendingDown size={16} className="text-red-400" />
    return <span className="text-zinc-500">→</span>
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* News Feed */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">📰</span>
            Interactive News Feed
          </h3>
          <div className="flex gap-2">
            <span className="text-sm text-zinc-500">{savedArticles.length} saved</span>
          </div>
        </div>
        
        <div className="grid gap-4">
          {INTERACTIVE_NEWS.map((news, idx) => (
            <div 
              key={news.id}
              className="card-sleek p-5 hover:border-zinc-600 transition-all cursor-pointer group"
              onClick={() => setSelectedNews(news)}
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2 text-sm">
                    <span className="text-zinc-500">{news.time}</span>
                    <span className="px-2 py-0.5 bg-zinc-800 rounded text-zinc-400">{news.source}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                      news.sentiment === 'bullish' ? 'bg-green-950 text-green-400' : 'bg-red-950 text-red-400'
                    }`}>
                      {news.sentiment.toUpperCase()}
                    </span>
                  </div>
                  <h4 className="font-bold text-lg mb-2 group-hover:text-blue-400 transition-colors">
                    {news.headline}
                  </h4>
                  <p className="text-zinc-400 text-sm line-clamp-2">{news.summary}</p>
                  
                  <div className="flex items-center gap-4 mt-3">
                    <span className="font-mono font-bold">{news.ticker}</span>
                    <div className="flex items-center gap-1 text-zinc-500 text-sm">
                      <ThumbsUp size={14} />
                      {likedArticles.includes(news.id) ? news.likes + 1 : news.likes}
                    </div>
                    <div className="flex items-center gap-1 text-zinc-500 text-sm">
                      <MessageCircle size={14} />
                      {news.comments}
                    </div>
                    <span className="text-zinc-600 text-sm">Click to read full article →</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2">
                  <button 
                    onClick={(e) => { e.stopPropagation(); toggleLike(news.id) }}
                    className={`p-2 rounded-lg transition-colors ${
                      likedArticles.includes(news.id) ? 'bg-blue-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                    }`}
                  >
                    <ThumbsUp size={18} />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); toggleSave(news.id) }}
                    className={`p-2 rounded-lg transition-colors ${
                      savedArticles.includes(news.id) ? 'bg-yellow-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                    }`}
                  >
                    <Bookmark size={18} />
                  </button>
                  <button className="p-2 rounded-lg bg-zinc-800 text-zinc-400 hover:bg-zinc-700 transition-colors">
                    <Share2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Stock Explorer */}
      <section>
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <span className="text-2xl">📊</span>
          Stock Explorer
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(STOCK_DETAILS).map(([ticker, details]) => (
            <div 
              key={ticker}
              className="card-sleek p-4 cursor-pointer hover:border-blue-500/50 transition-all group"
              onClick={() => setSelectedStock({ ticker, ...details })}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono font-bold text-xl">{ticker}</span>
                <ChevronRight size={18} className="text-zinc-600 group-hover:text-white transition-colors" />
              </div>
              <p className="text-zinc-400 text-xs mb-3 line-clamp-1">{details.company}</p>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Market Cap</span>
                  <span className="font-mono">{details.marketCap}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Sector</span>
                  <span className="text-zinc-300">{details.sector.split('/')[0]}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Sentiment Tracker */}
      <section>
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <span className="text-2xl">💭</span>
          Sentiment Tracker
        </h3>
        
        <div className="card-sleek p-6">
          <div className="flex gap-1 p-1 bg-zinc-950 rounded-lg border border-zinc-800 w-fit mb-6">
            {['market', 'stocks', 'sectors'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveSentimentTab(tab)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeSentimentTab === tab ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {activeSentimentTab === 'market' && (
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 bg-zinc-950 rounded-xl border border-zinc-800">
                <p className="text-zinc-500 text-sm mb-2">Overall Market Sentiment</p>
                <div className="text-6xl font-bold mb-2" style={{ 
                  color: SENTIMENT_DATA.market.score >= 70 ? '#22c55e' : SENTIMENT_DATA.market.score >= 50 ? '#eab308' : '#ef4444'
                }}>
                  {SENTIMENT_DATA.market.score}
                </div>
                <p className="text-lg font-medium text-zinc-300">
                  {SENTIMENT_DATA.market.score >= 70 ? 'Bullish 📈' : SENTIMENT_DATA.market.score >= 50 ? 'Neutral 😐' : 'Bearish 📉'}
                </p>
                <div className="flex items-center justify-center gap-2 mt-2 text-sm">
                  {getTrendIcon(SENTIMENT_DATA.market.trend)}
                  <span className={SENTIMENT_DATA.market.change > 0 ? 'text-green-400' : 'text-red-400'}>
                    {SENTIMENT_DATA.market.change > 0 ? '+' : ''}{SENTIMENT_DATA.market.change} today
                  </span>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium text-zinc-400">Sentiment Breakdown</h4>
                {Object.entries(SENTIMENT_DATA.sectors).map(([sector, data]) => (
                  <div key={sector} className="flex items-center gap-3">
                    <span className="text-sm capitalize w-24">{sector}</span>
                    <div className="flex-1 h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{ 
                          width: `${data.score}%`,
                          backgroundColor: data.score >= 70 ? '#22c55e' : data.score >= 50 ? '#eab308' : '#ef4444'
                        }}
                      />
                    </div>
                    <span className="text-sm font-mono w-12 text-right">{data.score}</span>
                    {getTrendIcon(data.trend)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSentimentTab === 'stocks' && (
            <div className="space-y-4">
              {Object.entries(SENTIMENT_DATA.stocks).map(([ticker, data]) => (
                <div key={ticker} className="p-4 bg-zinc-950 rounded-xl border border-zinc-800">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-mono font-bold text-lg">{ticker}</span>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      data.trend === 'very-bullish' ? 'bg-green-950 text-green-400' :
                      data.trend === 'bullish' ? 'bg-green-900/50 text-green-400' :
                      data.trend === 'bearish' ? 'bg-red-900/50 text-red-400' :
                      'bg-yellow-900/50 text-yellow-400'
                    }`}>
                      {data.trend.replace('-', ' ').toUpperCase()}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mb-3">
                    <div className="text-center">
                      <p className="text-xs text-zinc-500 mb-1">Social</p>
                      <p className={`font-bold ${data.social >= 70 ? 'text-green-400' : data.social >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                        {data.social}%
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-zinc-500 mb-1">News</p>
                      <p className={`font-bold ${data.news >= 70 ? 'text-green-400' : data.news >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                        {data.news}%
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-zinc-500 mb-1">Analysts</p>
                      <p className={`font-bold ${data.analyst >= 70 ? 'text-green-400' : data.analyst >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                        {data.analyst}%
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {data.keywords.map(keyword => (
                      <span key={keyword} className="px-2 py-1 bg-zinc-900 rounded text-xs text-zinc-400">
                        #{keyword}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* News Modal */}
      {selectedNews && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedNews(null)}>
          <div className="bg-zinc-900 rounded-2xl border border-zinc-700 max-w-2xl w-full max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold">{selectedNews.ticker}</span>
                <span className={`px-2 py-0.5 rounded text-xs ${
                  selectedNews.sentiment === 'bullish' ? 'bg-green-950 text-green-400' : 'bg-red-950 text-red-400'
                }`}>
                  {selectedNews.sentiment.toUpperCase()}
                </span>
              </div>
              <button onClick={() => setSelectedNews(null)} className="p-2 hover:bg-zinc-800 rounded-lg transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4">{selectedNews.headline}</h2>
              <div className="flex items-center gap-4 text-sm text-zinc-500 mb-6">
                <span>{selectedNews.source}</span>
                <span>•</span>
                <span>{selectedNews.time}</span>
                <span>•</span>
                <span>{selectedNews.likes} likes</span>
              </div>
              <div className="prose prose-invert max-w-none">
                {selectedNews.fullArticle.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-zinc-300 mb-4 leading-relaxed">{paragraph}</p>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-zinc-800">
                <p className="text-sm text-zinc-500 mb-2">Related Tickers:</p>
                <div className="flex gap-2">
                  {selectedNews.relatedTickers.map(ticker => (
                    <span key={ticker} className="px-3 py-1 bg-zinc-800 rounded-lg font-mono text-sm">{ticker}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stock Modal */}
      {selectedStock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedStock(null)}>
          <div className="bg-zinc-900 rounded-2xl border border-zinc-700 max-w-3xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-zinc-900 border-b border-zinc-800 p-4 flex items-center justify-between">
              <span className="font-mono font-bold text-xl">{selectedStock.ticker}</span>
              <button onClick={() => setSelectedStock(null)} className="p-2 hover:bg-zinc-800 rounded-lg transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-1">{selectedStock.company}</h2>
              <p className="text-zinc-400 mb-6">{selectedStock.sector}</p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="p-3 bg-zinc-950 rounded-lg">
                  <p className="text-xs text-zinc-500">Market Cap</p>
                  <p className="font-mono font-bold">{selectedStock.marketCap}</p>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg">
                  <p className="text-xs text-zinc-500">P/E Ratio</p>
                  <p className="font-mono font-bold">{selectedStock.peRatio}</p>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg">
                  <p className="text-xs text-zinc-500">Revenue Growth</p>
                  <p className="font-mono font-bold text-green-400">{selectedStock.revenueGrowth}</p>
                </div>
                <div className="p-3 bg-zinc-950 rounded-lg">
                  <p className="text-xs text-zinc-500">Profit Margin</p>
                  <p className="font-mono font-bold">{selectedStock.profitMargin}</p>
                </div>
              </div>

              <p className="text-zinc-300 mb-6 leading-relaxed">{selectedStock.description}</p>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-3">Key Products</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedStock.keyProducts.map(product => (
                      <span key={product} className="px-3 py-1 bg-zinc-800 rounded-lg text-sm">{product}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-3">Analyst Ratings</h4>
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-400">{selectedStock.analystRatings.buy}</p>
                      <p className="text-xs text-zinc-500">Buy</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-yellow-400">{selectedStock.analystRatings.hold}</p>
                      <p className="text-xs text-zinc-500">Hold</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-red-400">{selectedStock.analystRatings.sell}</p>
                      <p className="text-xs text-zinc-500">Sell</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-zinc-950 rounded-lg border border-zinc-800">
                <h4 className="font-bold mb-2">Insider Activity</h4>
                <p className="text-sm text-zinc-400">{selectedStock.insiderActivity}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
