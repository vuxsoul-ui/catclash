"use client"

const WATCHLIST = {
  hot: [
    { ticker: "PLTR", name: "Palantir", emoji: "🔮", price: "$85.20", thesis: "AI wizardry", risk: "High valuation" },
    { ticker: "RKLB", name: "Rocket Lab", emoji: "🚀", price: "$72.45", thesis: "Space money", risk: "Pre-profit" },
  ],
  defense: [
    { ticker: "AVAV", name: "AeroVironment", emoji: "🛸", price: "$215.40", thesis: "Drones!", risk: "Gov budgets" },
    { ticker: "KTOS", name: "Kratos", emoji: "⚔️", price: "28.15", thesis: "Hypersonics", risk: "Lumpy rev" },
  ],
  etfs: [
    { ticker: "QQQ", name: "Nasdaq 100", emoji: "📈", price: "$520.30", thesis: "Tech basket", risk: "Concentrated" },
    { ticker: "SOXX", name: "Semis", emoji: "🖥️", price: "$795.20", thesis: "Chips!", risk: "Cyclical" },
  ]
}

export function WatchlistPanel() {
  return (
    <div className="space-y-4 font-comic">
      {/* Hot Stocks */}
      <div>
        <h3 className="text-lg font-black text-black mb-2 flex items-center gap-2">
          <span className="text-2xl">🔥</span> Hot Stocks
        </h3>
        <div className="space-y-2">
          {WATCHLIST.hot.map((stock) => (
            <div key={stock.ticker} className="bg-gradient-to-r from-orange-400 to-red-400 p-3 rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform hover:scale-105 transition-transform cursor-pointer">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{stock.emoji}</span>
                <div className="flex-1">
                  <p className="font-black text-black">{stock.ticker}</p>
                  <p className="text-xs font-bold text-black/70">{stock.name}</p>
                </div>
                <div className="text-right">
                  <p className="font-black text-black">{stock.price}</p>
                </div>
              </div>
              <p className="text-xs font-bold mt-1 text-black/80">{stock.thesis}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Defense */}
      <div>
        <h3 className="text-lg font-black text-black mb-2 flex items-center gap-2">
          <span className="text-2xl">🛡️</span> Defense
        </h3>
        {WATCHLIST.defense.map((stock) => (
          <div key={stock.ticker} className="bg-green-400 p-3 rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-2 transform hover:scale-105 transition-transform cursor-pointer">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{stock.emoji}</span>
              <div className="flex-1">
                <p className="font-black text-black">{stock.ticker}</p>
                <p className="text-xs font-bold text-black/70">{stock.name}</p>
              </div>
              <p className="font-black text-black">{stock.price}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ETFs */}
      <div>
        <h3 className="text-lg font-black text-black mb-2 flex items-center gap-2">
          <span className="text-2xl">📦</span> ETFs
        </h3>
        {WATCHLIST.etfs.map((stock) => (
          <div key={stock.ticker} className="bg-blue-400 p-3 rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-2 transform hover:scale-105 transition-transform cursor-pointer">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{stock.emoji}</span>
              <div className="flex-1">
                <p className="font-black text-black">{stock.ticker}</p>
                <p className="text-xs font-bold text-black/70">{stock.name}</p>
              </div>
              <p className="font-black text-black">{stock.price}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tip */}
      <div className="bg-purple-300 p-3 rounded-xl border-3 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
        <p className="font-bold text-sm text-black text-center">
          💡 Click stocks to research!<br/>
          🚀 Or type them in the chat!
        </p>
      </div>
    </div>
  )
}
