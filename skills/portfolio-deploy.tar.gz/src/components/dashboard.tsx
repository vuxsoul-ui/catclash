"use client"

import { useState, useEffect } from "react"
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, 
  AreaChart, Area, PieChart, Pie, Cell
} from 'recharts'
import { 
  Download, History, TrendingUp, TrendingDown, DollarSign, 
  Activity, PieChart as PieIcon, BarChart3, LineChart as LineIcon,
  Target, AlertTriangle, Share2, Bell
} from "lucide-react"

const VPS_API_URL = "http://65.109.11.40:3001"
const USER_NAME = "Kai"

// Trade history
const TRADE_HISTORY = [
  { date: '2026-02-01', symbol: 'NVDA', action: 'BUY', shares: 10, price: 180.50, total: 1805 },
  { date: '2026-01-15', symbol: 'ONDS', action: 'BUY', shares: 100, price: 9.20, total: 920 },
  { date: '2026-01-10', symbol: 'SLS', action: 'BUY', shares: 50, price: 4.50, total: 225 },
]

// Recommended price alerts (not active - just suggestions)
const RECOMMENDED_ALERTS = [
  { symbol: 'NVDA', type: 'above', price: 200, rationale: "Breakout target - clear resistance level" },
  { symbol: 'NVDA', type: 'below', price: 165, rationale: "Stop loss - 10% drawdown protection" },
  { symbol: 'ONDS', type: 'above', price: 15, rationale: "Price target - 50% upside from current" },
  { symbol: 'ONDS', type: 'below', price: 8, rationale: "Support level - add on dip opportunity" },
  { symbol: 'SLS', type: 'above', price: 5, rationale: "FDA approval could spike price" },
]

export function Dashboard() {
  const [data, setData] = useState(null)
  const [sp500Data, setSp500Data] = useState({ value: 100, change: 0.8 })
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState('bars')
  const [timeRange, setTimeRange] = useState('1D')
  const [activeTab, setActiveTab] = useState('overview')

  const fetchData = async () => {
    try {
      const res = await fetch(`${VPS_API_URL}/api/portfolio`)
      const liveData = await res.json()
      setData(liveData)
    } catch (e) {
      console.error('Fetch error:', e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 30000)
    return () => clearInterval(interval)
  }, [])

  const exportToPDF = () => {
    const report = {
      date: new Date().toISOString(),
      portfolio: data,
      totalValue: data?.totalValue,
      totalPnl: data?.pnl,
    }
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `portfolio-report-${new Date().toISOString().split('T')[0]}.json`
    a.click()
  }

  const sharePortfolio = async () => {
    if (navigator.share) {
      await navigator.share({
        title: 'My Portfolio',
        text: `Portfolio Value: $${data?.totalValue?.toLocaleString()} | P&L: ${data?.pnl >= 0 ? '+' : ''}$${data?.pnl?.toLocaleString()}`,
        url: window.location.href
      })
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-white/20 border-t-white rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-zinc-500 font-mono text-sm">Loading market data...</p>
        </div>
      </div>
    )
  }

  if (!data) return null

  const chartData = data.holdings.map(h => ({
    name: h.symbol,
    value: h.value,
    cost: h.cost,
    pnl: h.pnl,
    allocation: ((h.value / data.totalValue) * 100).toFixed(1)
  }))

  const performanceData = [
    { time: '9:30', portfolio: data.totalValue * 0.985, sp500: 100 },
    { time: '10:30', portfolio: data.totalValue * 0.992, sp500: 100.2 },
    { time: '11:30', portfolio: data.totalValue * 1.005, sp500: 100.5 },
    { time: '12:30', portfolio: data.totalValue * 0.998, sp500: 100.3 },
    { time: '13:30', portfolio: data.totalValue, sp500: 100.8 },
  ]

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Portfolio Overview</h2>
          <p className="text-zinc-500 text-sm mt-1">
            <span className="relative flex h-3 w-3 inline-block mr-2 align-middle">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            Market Open • Last updated: {new Date().toLocaleTimeString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={exportToPDF} className="btn-sleek flex items-center gap-2">
            <Download size={16} />
            <span className="hidden sm:inline">Export</span>
          </button>
          <button onClick={sharePortfolio} className="btn-sleek flex items-center gap-2">
            <Share2 size={16} />
            <span className="hidden sm:inline">Share</span>
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card-sleek p-5">
          <p className="text-zinc-500 text-sm font-medium">Total Value</p>
          <p className="text-3xl font-bold mt-1 font-mono">
            ${data.totalValue.toLocaleString(undefined, {maximumFractionDigits: 0})}
          </p>
          <div className="flex items-center gap-2 mt-2">
            <TrendingUp size={14} className="text-zinc-600" />
            <span className="text-xs text-zinc-500">vs yesterday</span>
          </div>
        </div>

        <div className={`card-sleek p-5 ${data.pnl >= 0 ? 'glow-success' : 'glow-danger'}`}>
          <p className="text-zinc-500 text-sm font-medium">Total P&L</p>
          <p className={`text-3xl font-bold mt-1 font-mono ${data.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {data.pnl >= 0 ? '+' : ''}${data.pnl.toLocaleString(undefined, {maximumFractionDigits: 0})}
          </p>
          <p className={`text-sm font-medium mt-2 ${data.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {data.pnlPct >= 0 ? '+' : ''}{data.pnlPct.toFixed(2)}%
          </p>
        </div>

        <div className="card-sleek p-5">
          <p className="text-zinc-500 text-sm font-medium">Day's Gain</p>
          <p className="text-3xl font-bold mt-1 font-mono">
            ${data.holdings.reduce((sum, h) => sum + (h.value - (h.value / (1 + h.change/100))), 0).toFixed(0)}
          </p>
          <div className="flex items-center gap-2 mt-2">
            <Activity size={14} className="text-zinc-600" />
            <span className="text-xs text-zinc-500">Realized + Unrealized</span>
          </div>
        </div>

        <div className="card-sleek p-5">
          <p className="text-zinc-500 text-sm font-medium">vs S&P 500</p>
          <p className="text-3xl font-bold mt-1 font-mono">
            {((data.pnlPct - sp500Data.change)).toFixed(1)}%
          </p>
          <p className="text-sm text-zinc-500 mt-2">
            {data.pnlPct > sp500Data.change ? 'Outperforming' : 'Underperforming'}
          </p>
        </div>
      </div>

      {/* Tabs - Removed 'alerts' tab */}
      <div className="flex gap-1 p-1 bg-zinc-950 rounded-lg border border-zinc-800 w-fit">
        {[
          { id: 'overview', label: 'Overview', icon: PieIcon },
          { id: 'performance', label: 'Performance', icon: LineIcon },
          { id: 'holdings', label: 'Holdings', icon: BarChart3 },
          { id: 'history', label: 'History', icon: History },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.id 
                ? 'bg-zinc-800 text-white' 
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <tab.icon size={14} />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chart */}
          <div className="lg:col-span-2 card-sleek p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold">Portfolio Allocation</h3>
              <div className="flex gap-2">
                {['bars', 'pie', 'area'].map(mode => (
                  <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`p-2 rounded-md transition-all ${viewMode === mode ? 'bg-zinc-800 text-white' : 'text-zinc-600 hover:text-zinc-400'}`}
                  >
                    {mode === 'bars' && <BarChart3 size={16} />}
                    {mode === 'pie' && <PieIcon size={16} />}
                    {mode === 'area' && <LineIcon size={16} />}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                {viewMode === 'bars' && (
                  <BarChart data={chartData}>
                    <XAxis dataKey="name" stroke="#52525b" fontSize={12} />
                    <YAxis stroke="#52525b" fontSize={12} tickFormatter={(v) => `$${v/1000}k`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                      itemStyle={{ color: '#fff' }}
                      formatter={(val) => [`$${val.toLocaleString()}`, '']}
                    />
                    <Bar dataKey="value" fill="#fff" radius={[4, 4, 0, 0]} />
                  </BarChart>
                )}
                {viewMode === 'pie' && (
                  <PieChart>
                    <Pie data={chartData} dataKey="value" cx="50%" cy="50%" outerRadius={100}>
                      {chartData.map((_, i) => (
                        <Cell key={i} fill={['#fff', '#a1a1aa', '#71717a', '#52525b'][i % 4]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(val) => `$${val.toLocaleString()}`} />
                  </PieChart>
                )}
                {viewMode === 'area' && (
                  <AreaChart data={performanceData}>
                    <XAxis dataKey="time" stroke="#52525b" fontSize={12} />
                    <YAxis stroke="#52525b" fontSize={12} domain={['auto', 'auto']} />
                    <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a' }} />
                    <Area type="monotone" dataKey="portfolio" stroke="#fff" fill="#fff" fillOpacity={0.1} />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Side Panel - Top Movers + Recommended Alerts */}
          <div className="space-y-4">
            <div className="card-sleek p-5">
              <h3 className="font-semibold mb-4">Top Movers</h3>
              <div className="space-y-3">
                {[...data.holdings].sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).map(h => (
                  <div key={h.symbol} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold">{h.symbol}</span>
                      <span className="text-zinc-500 text-sm">{h.shares} sh</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono">${h.price.toFixed(2)}</span>
                      <span className={`ml-2 text-sm ${h.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {h.change >= 0 ? '+' : ''}{h.change.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommended Alerts Section */}
            <div className="card-sleek p-5">
              <div className="flex items-center gap-2 mb-4">
                <Bell size={18} className="text-yellow-500" />
                <h3 className="font-semibold">Recommended Alerts</h3>
              </div>
              <p className="text-xs text-zinc-500 mb-3">
                Set these in your broker app:
              </p>
              <div className="space-y-2">
                {RECOMMENDED_ALERTS.map((alert, idx) => (
                  <div key={idx} className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold">{alert.symbol}</span>
                      <span className={`text-xs px-2 py-0.5 rounded ${
                        alert.type === 'above' ? 'bg-green-950 text-green-400' : 'bg-red-950 text-red-400'
                      }`}>
                        {alert.type === 'above' ? '≥' : '≤'} ${alert.price}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-500">{alert.rationale}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'performance' && (
        <div className="card-sleek p-6">
          <h3 className="font-semibold mb-4">Performance vs S&P 500</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <XAxis dataKey="time" stroke="#52525b" />
                <YAxis stroke="#52525b" />
                <Tooltip contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a' }} />
                <Line type="monotone" dataKey="portfolio" stroke="#fff" strokeWidth={2} dot={false} name="Portfolio" />
                <Line type="monotone" dataKey="sp500" stroke="#71717a" strokeWidth={2} strokeDasharray="5 5" dot={false} name="S&P 500" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {activeTab === 'holdings' && (
        <div className="card-sleek overflow-hidden">
          <table className="w-full">
            <thead className="bg-zinc-950 border-b border-zinc-800">
              <tr>
                <th className="text-left p-4 font-medium text-zinc-400">Symbol</th>
                <th className="text-right p-4 font-medium text-zinc-400">Price</th>
                <th className="text-right p-4 font-medium text-zinc-400">Change</th>
                <th className="text-right p-4 font-medium text-zinc-400">Shares</th>
                <th className="text-right p-4 font-medium text-zinc-400">Value</th>
                <th className="text-right p-4 font-medium text-zinc-400">P&L</th>
              </tr>
            </thead>
            <tbody>
              {data.holdings.map(h => (
                <tr key={h.symbol} className="border-b border-zinc-800/50 hover:bg-zinc-900/50 transition-colors">
                  <td className="p-4 font-mono font-bold">{h.symbol}</td>
                  <td className="p-4 text-right font-mono">${h.price.toFixed(2)}</td>
                  <td className={`p-4 text-right ${h.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {h.change >= 0 ? '+' : ''}{h.change.toFixed(1)}%
                  </td>
                  <td className="p-4 text-right text-zinc-400">{h.shares}</td>
                  <td className="p-4 text-right font-mono">${h.value.toLocaleString()}</td>
                  <td className={`p-4 text-right font-mono ${h.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {h.pnl >= 0 ? '+' : ''}${h.pnl.toFixed(0)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="card-sleek overflow-hidden">
          <table className="w-full">
            <thead className="bg-zinc-950 border-b border-zinc-800">
              <tr>
                <th className="text-left p-4 font-medium text-zinc-400">Date</th>
                <th className="text-left p-4 font-medium text-zinc-400">Symbol</th>
                <th className="text-left p-4 font-medium text-zinc-400">Action</th>
                <th className="text-right p-4 font-medium text-zinc-400">Shares</th>
                <th className="text-right p-4 font-medium text-zinc-400">Price</th>
                <th className="text-right p-4 font-medium text-zinc-400">Total</th>
              </tr>
            </thead>
            <tbody>
              {TRADE_HISTORY.map((trade, i) => (
                <tr key={i} className="border-b border-zinc-800/50 hover:bg-zinc-900/50 transition-colors">
                  <td className="p-4 text-zinc-400">{trade.date}</td>
                  <td className="p-4 font-mono font-bold">{trade.symbol}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      trade.action === 'BUY' ? 'bg-green-950 text-green-400' : 'bg-red-950 text-red-400'
                    }`}>
                      {trade.action}
                    </span>
                  </td>
                  <td className="p-4 text-right">{trade.shares}</td>
                  <td className="p-4 text-right font-mono">${trade.price.toFixed(2)}</td>
                  <td className="p-4 text-right font-mono">${trade.total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
