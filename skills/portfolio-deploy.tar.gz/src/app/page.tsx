import { Dashboard } from "@/components/dashboard"
import { AIAdvisor } from "@/components/ai-advisor"
import { MarketIntelligence } from "@/components/market-intelligence"
import { InteractiveFeatures } from "@/components/interactive-features"
import { SentimentTracker } from "@/components/sentiment-tracker"
import { ApeWisdomTracker } from "@/components/apewisdom-tracker"

export const metadata = {
  title: 'Portfolio Pro | Kai',
  description: 'Professional portfolio tracking and AI-powered investment recommendations',
  manifest: '/manifest.json',
}

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-zinc-900 bg-black/80 backdrop-blur-xl sticky top-0 z-40 animate-fade-in">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center animate-glow">
                <span className="text-black font-bold text-xl">K</span>
              </div>
              <div>
                <h1 className="font-bold text-lg tracking-tight">Portfolio Pro</h1>
                <p className="text-zinc-500 text-xs">AI-Powered Investment Intelligence</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-zinc-900 rounded-full border border-zinc-800">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-zinc-400">Live Market Data</span>
              </div>
              <div className="w-8 h-8 bg-gradient-to-br from-zinc-700 to-zinc-800 rounded-full flex items-center justify-center border border-zinc-700">
                <span className="text-sm font-medium">K</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Section */}
        <section className="mb-8 animate-fade-in">
          <Dashboard />
        </section>

        {/* AI Advisor Section */}
        <section className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-2xl">🦞</span>
                AI Investment Advisor
              </h2>
              <p className="text-zinc-500 text-sm mt-1">
                Personalized recommendations based on your current holdings
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-zinc-500">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              Analyzing 29 market factors
            </div>
          </div>
          <AIAdvisor />
        </section>

        {/* Market Intelligence Section */}
        <section className="mt-12 animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-2xl">📡</span>
                Market Intelligence
              </h2>
              <p className="text-zinc-500 text-sm mt-1">
                News, whale activity, insider trades & sentiment analysis
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-zinc-500">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
              Real-time monitoring
            </div>
          </div>
          <MarketIntelligence />
        </section>

        {/* Interactive Features Section */}
        <section className="mt-12 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-2xl">🎮</span>
                Interactive Hub
              </h2>
              <p className="text-zinc-500 text-sm mt-1">
                Click news to read full articles, explore stocks, track sentiment
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-zinc-500">
              <span className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></span>
              Fully interactive
            </div>
          </div>
          <InteractiveFeatures />
        </section>

        {/* Sentiment Tracker Section */}
        <section className="mt-12 animate-slide-up" style={{ animationDelay: '0.5s' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-2xl">💭</span>
                Market Sentiment Tracker
              </h2>
              <p className="text-zinc-500 text-sm mt-1">
                Real-time sentiment analysis across markets, sectors, and social media
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-zinc-500">
              <span className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></span>
              Live data
            </div>
          </div>
          <SentimentTracker />
        </section>

        {/* ApeWisdom Tracker Section */}
        <section className="mt-12 animate-slide-up" style={{ animationDelay: '0.6s' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <span className="text-2xl">🦍</span>
                ApeWisdom Tracker
              </h2>
              <p className="text-zinc-500 text-sm mt-1">
                Reddit & WallStreetBets sentiment, trending stocks, and retail investor activity
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-zinc-500">
              <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></span>
              WSB monitored
            </div>
          </div>
          <ApeWisdomTracker />
        </section>

        {/* Features Grid */}
        <section className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          <div className="card-sleek p-6 group hover:border-zinc-600 transition-all">
            <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <span className="text-2xl">🎯</span>
            </div>
            <h3 className="font-bold text-lg mb-2">Smart Allocation</h3>
            <p className="text-zinc-500 text-sm">
              Reduce NVDA concentration from 64% to optimal 35%. Diversify into defense, international, and index ETFs.
            </p>
          </div>

          <div className="card-sleek p-6 group hover:border-zinc-600 transition-all">
            <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <span className="text-2xl">🔔</span>
            </div>
            <h3 className="font-bold text-lg mb-2">Price Alerts</h3>
            <p className="text-zinc-500 text-sm">
              Set smart alerts for NVDA at $200, ONDS at $15. Get notified when targets hit or opportunities emerge.
            </p>
          </div>

          <div className="card-sleek p-6 group hover:border-zinc-600 transition-all">
            <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <span className="text-2xl">📊</span>
            </div>
            <h3 className="font-bold text-lg mb-2">Risk Analysis</h3>
            <p className="text-zinc-500 text-sm">
              Current risk score: 8.5/10 (High). Reduce to 6/10 by adding index ETFs and international diversification.
            </p>
          </div>
        </section>

        {/* Recommended Sectors */}
        <section className="mt-12 animate-slide-up" style={{ animationDelay: '0.6s' }}>
          <h2 className="text-2xl font-bold mb-6">Recommended Sectors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card-sleek p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">🛡️ Defense & Aerospace</h3>
                <span className="px-2 py-1 bg-green-950 text-green-400 rounded text-xs font-medium">Complements ONDS</span>
              </div>
              <div className="space-y-3">
                {[
                  { ticker: 'AVAV', name: 'AeroVironment', price: '$215.40', thesis: 'Drones & unmanned systems' },
                  { ticker: 'LMT', name: 'Lockheed Martin', price: '$485.20', thesis: 'Stable defense giant' },
                ].map(stock => (
                  <div key={stock.ticker} className="flex items-center justify-between p-3 bg-zinc-950 rounded-lg border border-zinc-800 hover:border-zinc-600 transition-colors">
                    <div>
                      <span className="font-mono font-bold">{stock.ticker}</span>
                      <p className="text-xs text-zinc-500">{stock.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-medium">{stock.price}</p>
                      <p className="text-xs text-zinc-500">{stock.thesis}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="card-sleek p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">🤖 AI & Semiconductors</h3>
                <span className="px-2 py-1 bg-blue-950 text-blue-400 rounded text-xs font-medium">NVDA Ecosystem</span>
              </div>
              <div className="space-y-3">
                {[
                  { ticker: 'ASML', name: 'ASML Holding', price: '$765.40', thesis: 'EUV lithography monopoly' },
                  { ticker: 'TSM', name: 'Taiwan Semi', price: '$185.60', thesis: 'NVDA manufacturer' },
                ].map(stock => (
                  <div key={stock.ticker} className="flex items-center justify-between p-3 bg-zinc-950 rounded-lg border border-zinc-800 hover:border-zinc-600 transition-colors">
                    <div>
                      <span className="font-mono font-bold">{stock.ticker}</span>
                      <p className="text-xs text-zinc-500">{stock.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-medium">{stock.price}</p>
                      <p className="text-xs text-zinc-500">{stock.thesis}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-zinc-900 mt-12 py-8 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-zinc-600">
            <p>© 2026 Portfolio Pro. All rights reserved.</p>
            <div className="flex items-center gap-4">
              <span className="font-mono">Data: Alpaca Markets</span>
              <span className="font-mono">AI: Claude</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}
